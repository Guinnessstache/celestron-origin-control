@echo off
echo Fixing Celestron Origin Control desktop icon...
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0FixIcon.ps1"
pause
