'use strict';

const $   = id => document.getElementById(id);
const api = window.telescopeAPI;

// ── State ──────────────────────────────────────────────────────────────────
const state = {
  connected:    false,
  ip:           null,
  streaming:    false,
  recording:    false,
  recFilePath:  null,
  slewSpeed:    6,
  quality:      '720p',
  signedIn:     false,
  channelName:  null,
  statusTimer:  null,
  userLat:      undefined,
  userLon:      undefined,
  locationName: '',
};

// ── Init ───────────────────────────────────────────────────────────────────
(async () => {
  checkFFmpeg();
  await refreshAuthUI();

  // Wire event listeners from main process
  api.onScanProgress(({ scanned, total }) => {
    const pct = Math.round((scanned / total) * 100);
    $('scanFill').style.width = pct + '%';
    $('scanLabel').textContent = `Scanning… ${scanned}/${total}`;
  });

  api.onStreamStatus(handleStreamStatus);
  api.onStreamLog(appendStreamLog);
  api.onRecordStatus(handleRecordStatus);

  // Update firmware display whenever the live WebSocket reports version
  api.onVersion(v => {
    if (v && v !== 'Unknown') {
      $('infoFirmware').textContent = v;
    }
  });
})();

// ── Toast ──────────────────────────────────────────────────────────────────
function toast(msg, type='info', ms=3200) {
  const el = $('toast');
  el.textContent = msg;
  el.className   = `toast show ${type}`;
  clearTimeout(el._t);
  el._t = setTimeout(() => { el.className = 'toast'; }, ms);
}

// ── Tabs ───────────────────────────────────────────────────────────────────
document.querySelectorAll('.nav-tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
    document.querySelectorAll('.tab-panel').forEach(p => p.classList.remove('active'));
    tab.classList.add('active');
    $(`tab-${tab.dataset.tab}`).classList.add('active');

    // Per-tab hooks
    const t = tab.dataset.tab;
    if (t === 'control') {
      if (state.userLat === undefined) loadTonightTargets();
      else renderTonightTargets(state.userLat, state.userLon, state.locationName);
    }
    if (t === 'telescope') {
      if (state.connected) loadTelescopeSettings();
      else {
        ['tsModel','tsFirmware','tsSerial'].forEach(id => {
          const e = $(id); if (e) e.textContent = 'Connect telescope first';
        });
      }
    }
  });
});

// ── Discovery ──────────────────────────────────────────────────────────────
$('btnDiscover').addEventListener('click', async () => {
  const btn  = $('btnDiscover');
  const list = $('discoveryList');
  const prog = $('scanProgress');

  btn.disabled    = true;
  btn.textContent = 'Scanning…';
  list.innerHTML  = '';
  list.classList.add('hidden');
  prog.classList.remove('hidden');
  $('scanFill').style.width = '0%';
  $('scanLabel').textContent = 'Scanning…';
  $('connDot').className = 'conn-dot connecting';

  const results = await api.discover();

  prog.classList.add('hidden');
  btn.disabled    = false;
  btn.innerHTML   = `<svg viewBox="0 0 20 20" fill="currentColor" width="13"><path d="M9 3a6 6 0 100 12A6 6 0 009 3zm-8 6a8 8 0 1114.32 4.906l3.387 3.387-1.414 1.414-3.387-3.387A8 8 0 011 9z"/></svg> Discover on Network`;
  $('connDot').className = 'conn-dot';

  if (!results.length) {
    toast('No telescopes found. Try entering the IP manually.', 'error');
    return;
  }

  list.classList.remove('hidden');
  results.forEach(({ ip }) => {
    const item = document.createElement('div');
    item.className   = 'discovery-item';
    item.textContent = ip;
    item.addEventListener('click', () => connectTo(ip));
    list.appendChild(item);
  });
});

$('btnConnectManual').addEventListener('click', () => {
  const ip = $('manualIpInput').value.trim();
  if (!ip) { toast('Enter an IP address', 'error'); return; }
  connectTo(ip);
});
$('manualIpInput').addEventListener('keydown', e => { if (e.key==='Enter') $('btnConnectManual').click(); });

async function connectTo(ip) {
  $('connDot').className  = 'conn-dot connecting';
  $('connLabel').textContent = 'Connecting…';
  toast(`Connecting to ${ip}…`, 'info');

  const r = await api.connect(ip);
  if (r.success) {
    setConnected(ip, r.info || {});
    $('discoveryList').classList.add('hidden');
  } else {
    $('connDot').className  = 'conn-dot';
    $('connLabel').textContent = 'Disconnected';
    toast(`Connection failed: ${r.error}`, 'error');
  }
}

function setConnected(ip, info) {
  state.connected = true;
  state.ip        = ip;
  $('connDot').className     = 'conn-dot connected';
  $('connLabel').textContent = 'Connected';
  $('connIp').textContent    = ip;
  $('infoIp').textContent    = ip;
  $('infoModel').textContent = info.model    || 'Celestron Origin';
  $('infoFirmware').textContent = info.firmware || 'Unknown';
  $('streamFeedStatus').textContent = ip;
  $('streamFeedStatus').classList.remove('dim');
  updateGoLiveBtn();
  loadStream(ip);
  startStatusPoll(ip);
  loadTonightTargets();
  toast(`✓ Connected to ${ip}`, 'success');
}

// ── Stream feed ────────────────────────────────────────────────────────────
let streamCheckTimer = null;
let activeWebSocket   = null;

function stopStream() {
  if (activeWebSocket) {
    try { activeWebSocket.close(); } catch(_){}
    activeWebSocket = null;
  }
  if (streamCheckTimer) { clearTimeout(streamCheckTimer); streamCheckTimer = null; }
  api.stopFrames();
  api.stopProxy();
}

async function loadStream(ip) {
  const img     = $('telescopeStream');
  const canvas  = $('telescopeCanvas');
  const overlay = $('videoOverlay');

  stopStream();
  img.src           = '';
  img.style.display = 'none';
  img.classList.add('hidden');
  if (canvas) canvas.classList.add('hidden');
  overlay.style.display = '';
  overlay.innerHTML = `
    <div class="no-signal">
      <svg viewBox="0 0 80 80" fill="none" width="72">
        <circle cx="40" cy="40" r="36" stroke="#7eb8f7" stroke-width="1" opacity="0.3"/>
        <circle cx="40" cy="40" r="20" stroke="#7eb8f7" stroke-width="1" opacity="0.5"/>
        <circle cx="40" cy="40" r="4"  fill="#7eb8f7" opacity="0.7"/>
        <line x1="40" y1="4" x2="40" y2="76" stroke="#7eb8f7" stroke-width="0.5" opacity="0.2"/>
        <line x1="4"  y1="40" x2="76" y2="40" stroke="#7eb8f7" stroke-width="0.5" opacity="0.2"/>
      </svg>
      <p>Searching for video stream…</p>
      <span class="no-signal-sub">Probing telescope endpoints</span>
    </div>`;

  const result = await api.findStream(ip);

  if (!result.success) {
    const portsMsg = result.openPorts?.length
      ? `Open ports: ${result.openPorts.join(', ')}`
      : 'No open ports detected';
    overlay.innerHTML = `
      <div class="no-signal">
        <svg viewBox="0 0 80 80" fill="none" width="72">
          <circle cx="40" cy="40" r="36" stroke="#ff4757" stroke-width="1" opacity="0.3"/>
          <circle cx="40" cy="40" r="20" stroke="#ff4757" stroke-width="1" opacity="0.4"/>
        </svg>
        <p style="color:var(--red)">No video stream found</p>
        <span class="no-signal-sub">
          ${portsMsg}<br>
          Make sure the telescope is actively imaging in the Celestron app.<br>
          Click <strong>Scan Ports</strong> above for full diagnostics.
        </span>
      </div>`;
    toast(`No stream found. ${portsMsg}. Click Scan Ports for details.`, 'error', 8000);
    return;
  }

  $('infoStream').textContent = result.url;

  if (result.type === 'origin') {
    // Celestron Origin protocol: WebSocket notifications + HTTP JPEG fetches
    overlay.innerHTML = `
      <div class="no-signal">
        <svg viewBox="0 0 80 80" fill="none" width="72">
          <circle cx="40" cy="40" r="36" stroke="#7eb8f7" stroke-width="1" opacity="0.3"/>
          <circle cx="40" cy="40" r="20" stroke="#7eb8f7" stroke-width="1" opacity="0.5"/>
          <circle cx="40" cy="40" r="4"  fill="#7eb8f7" opacity="0.7"/>
        </svg>
        <p>Connecting to live view…</p>
        <span class="no-signal-sub">Waiting for first frame from telescope</span>
      </div>`;

    let canvasEl = $('telescopeCanvas');
    if (!canvasEl) {
      canvasEl = document.createElement('canvas');
      canvasEl.id = 'telescopeCanvas';
      canvasEl.style.cssText = 'width:100%;height:100%;object-fit:contain;display:none;';
      $('videoFrame').appendChild(canvasEl);
    }
    canvasEl.style.display = 'none';

    let firstFrame = true;

    api.onFrame((b64) => {
      const dataUrl = 'data:image/jpeg;base64,' + b64;
      const imgEl   = new Image();
      imgEl.onload  = () => {
        canvasEl.width  = imgEl.naturalWidth;
        canvasEl.height = imgEl.naturalHeight;
        canvasEl.getContext('2d').drawImage(imgEl, 0, 0);
        if (firstFrame) {
          firstFrame = false;
          clearTimeout(streamCheckTimer);
          overlay.style.display  = 'none';
          canvasEl.style.display = 'block';
          toast('Live view active', 'success');
        }
      };
      imgEl.src = dataUrl;
    });

    api.onFrameError((msg) => toast('Stream error: ' + msg, 'error'));

    // Start WebSocket + frame fetcher in main process
    await api.startFrames(result.url, result.baseUrl, result.startFrame);

    // Request firmware version through the now-open live WebSocket
    setTimeout(() => api.requestVersion(), 1000);

    // Timeout after 15s
    streamCheckTimer = setTimeout(() => {
      if (firstFrame) {
        overlay.innerHTML = `
          <div class="no-signal">
            <p style="color:var(--red)">No frames received</p>
            <span class="no-signal-sub">
              Check Stream Diagnostics above.<br>
              Is the telescope powered on and imaging?
            </span>
          </div>`;
        overlay.style.display = '';
      }
    }, 15000);

  } else if (result.type === 'websocket') {
    loadWebSocketStream(result.url, result.protocol || null, overlay);
  } else {
    // Generic MJPEG fallback
    overlay.innerHTML = `<div class="no-signal"><p>Connecting…</p></div>`;
    let canvasEl = $('telescopeCanvas');
    if (!canvasEl) {
      canvasEl = document.createElement('canvas');
      canvasEl.id = 'telescopeCanvas';
      canvasEl.style.cssText = 'width:100%;height:100%;object-fit:contain;display:none;';
      $('videoFrame').appendChild(canvasEl);
    }
    let firstFrame = true;
    api.onFrame((b64) => {
      const img2 = new Image();
      img2.onload = () => {
        canvasEl.width = img2.naturalWidth; canvasEl.height = img2.naturalHeight;
        canvasEl.getContext('2d').drawImage(img2, 0, 0);
        if (firstFrame) { firstFrame=false; overlay.style.display='none'; canvasEl.style.display='block'; toast('Live view active','success'); }
      };
      img2.src = 'data:image/jpeg;base64,' + b64;
    });
    await api.startFrames(result.url, result.baseUrl);
    streamCheckTimer = setTimeout(() => { if(firstFrame){overlay.innerHTML='<div class="no-signal"><p style="color:var(--red)">No frames</p></div>';} }, 15000);
  }
}

function loadWebSocketStream(wsUrl, protocol, overlay) {
  let canvasEl = $('telescopeCanvas');
  if (!canvasEl) {
    canvasEl = document.createElement('canvas');
    canvasEl.id = 'telescopeCanvas';
    canvasEl.style.cssText = 'width:100%;height:100%;object-fit:contain;display:none;';
    $('videoFrame').appendChild(canvasEl);
  }

  const ws = protocol ? new WebSocket(wsUrl, protocol) : new WebSocket(wsUrl);
  activeWebSocket = ws;
  ws.binaryType = 'arraybuffer';

  let firstFrame = true;

  ws.onopen = () => {
    toast('WebSocket connected — waiting for frames', 'info');
    // Try common init messages the telescope might need
    try { ws.send(JSON.stringify({ type: 'subscribe', channel: 'video' })); } catch(_){}
    try { ws.send(JSON.stringify({ cmd: 'stream', action: 'start' })); } catch(_){}
    try { ws.send(JSON.stringify({ action: 'startStream' })); } catch(_){}
  };

  ws.onmessage = (evt) => {
    if (typeof evt.data === 'string') {
      // Text frame — log it for diagnostics, may contain a stream URL
      console.log('WS text message:', evt.data.slice(0, 200));
      try {
        const j = JSON.parse(evt.data);
        // If the server sends back a stream URL in JSON, use it
        const streamUrl = j.url || j.stream || j.videoUrl || j.streamUrl;
        if (streamUrl && typeof streamUrl === 'string') {
          const imgEl = $('telescopeStream');
          imgEl.src = streamUrl.startsWith('http') ? streamUrl : `http://${state.ip}${streamUrl}`;
          imgEl.onload = () => { overlay.style.display='none'; imgEl.classList.remove('hidden'); };
          setTimeout(() => { overlay.style.display='none'; imgEl.classList.remove('hidden'); }, 2000);
        }
      } catch(_){}
      return;
    }

    // Binary frame — treat as JPEG
    const blob = new Blob([evt.data], { type: 'image/jpeg' });
    const url  = URL.createObjectURL(blob);
    const img2 = new Image();
    img2.onload = () => {
      const ctx = canvasEl.getContext('2d');
      canvasEl.width  = img2.naturalWidth  || 1280;
      canvasEl.height = img2.naturalHeight || 720;
      ctx.drawImage(img2, 0, 0);
      URL.revokeObjectURL(url);
      if (firstFrame) {
        firstFrame = false;
        overlay.style.display = 'none';
        canvasEl.style.display = 'block';
        toast('Live view active', 'success');
      }
    };
    img2.src = url;
  };

  ws.onerror = () => toast('WebSocket stream error', 'error');

  ws.onclose = () => {
    activeWebSocket = null;
    if (firstFrame) {
      // Never got a frame — show error
      overlay.innerHTML = `
        <div class="no-signal">
          <p style="color:var(--red)">Stream disconnected</p>
          <span class="no-signal-sub">The telescope closed the connection.<br>Is it actively imaging?</span>
        </div>`;
      overlay.style.display = '';
      canvasEl.style.display = 'none';
    }
  };
}

// ── Status polling ─────────────────────────────────────────────────────────
function startStatusPoll(ip) {
  stopStatusPoll();
  state.statusTimer = setInterval(async () => {
    const r = await api.getStatus(ip);
    if (!r.success) return;
    const s = r.status;
    if (s.RA        != null) $('posRA').textContent  = fmtRA(s.RA);
    if (s.Dec       != null) $('posDec').textContent = fmtDec(s.Dec);
    if (s.Altitude  != null) $('posAlt').textContent = `${(+s.Altitude).toFixed(2)}°`;
    if (s.Azimuth   != null) $('posAz').textContent  = `${(+s.Azimuth).toFixed(2)}°`;
    const tb = $('trackingBadge');
    tb.textContent = s.Tracking ? 'ON' : 'OFF';
    tb.className   = 'status-badge' + (s.Tracking ? ' on' : '');
  }, 3000);
}
function stopStatusPoll() { clearInterval(state.statusTimer); }

function fmtRA(v) {
  if (v==null) return '—';
  const h = Math.floor(v), m = Math.floor((v-h)*60), s = Math.floor(((v-h)*60-m)*60);
  return `${pad(h)}h ${pad(m)}m ${pad(s)}s`;
}
function fmtDec(v) {
  if (v==null) return '—';
  const sg = v>=0?'+':'-', a=Math.abs(v), d=Math.floor(a), m=Math.floor((a-d)*60), s=Math.floor(((a-d)*60-m)*60);
  return `${sg}${pad(d)}° ${pad(m)}' ${pad(s)}"`;
}
function pad(n) { return String(n).padStart(2,'0'); }

// ── YouTube Streaming (OBS-style — stream key only) ──────────────────────────
// No OAuth needed. User gets stream key from YouTube Studio and pastes it in.
api.openExternal && $('ytDashLink') && $('ytDashLink').addEventListener('click', e => {
  e.preventDefault(); api.openExternal('https://studio.youtube.com/');
});
$('ytStudioLink') && $('ytStudioLink').addEventListener('click', e => {
  e.preventDefault(); api.openExternal('https://studio.youtube.com/');
});
$('ytStep1Link') && $('ytStep1Link').addEventListener('click', e => {
  e.preventDefault(); api.openExternal('https://studio.youtube.com/');
});

// Load saved stream key
// Stream key is saved via localStorage automatically

// ── Platform selector ──────────────────────────────────────────────────────
let streamPlatform = 'youtube'; // 'youtube' | 'twitch'

document.querySelectorAll('.platform-btn').forEach(btn => {
  btn.addEventListener('click', () => {
    if (state.streaming) return; // don't switch while live
    document.querySelectorAll('.platform-btn').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    streamPlatform = btn.dataset.platform;
    $('panelYouTube').classList.toggle('hidden', streamPlatform !== 'youtube');
    $('panelTwitch').classList.toggle('hidden',  streamPlatform !== 'twitch');
    updateGoLiveBtn();
  });
});

// ── YouTube auth ───────────────────────────────────────────────────────────



// ── Twitch key ─────────────────────────────────────────────────────────────
// Persist Twitch key across sessions using localStorage
const TWITCH_KEY_STORE = 'twitchStreamKey';
(function loadTwitchKey() {
  try { const k = localStorage.getItem(TWITCH_KEY_STORE); if (k) $('twitchKeyInput').value = k; } catch(_) {}
})();

$('twitchKeyInput').addEventListener('input', () => {
  try { localStorage.setItem(TWITCH_KEY_STORE, $('twitchKeyInput').value); } catch(_) {}
  updateGoLiveBtn();
});

$('btnToggleTwitchKey').addEventListener('click', () => {
  const inp = $('twitchKeyInput');
  inp.type = inp.type === 'password' ? 'text' : 'password';
});

$('twitchDashLink').addEventListener('click', e => { e.preventDefault(); api.openExternal('https://dashboard.twitch.tv/u/settings/stream'); });

// ── Stream key input (YouTube) ─────────────────────────────────────────────
$('btnToggleKey').addEventListener('click', () => {
  const inp = $('streamKeyInput');
  inp.type  = inp.type === 'password' ? 'text' : 'password';
});
// Save/restore YouTube stream key across sessions
const YT_KEY_STORAGE = 'yt_stream_key';
try {
  const saved = localStorage.getItem(YT_KEY_STORAGE);
  if (saved && $('streamKeyInput')) $('streamKeyInput').value = saved;
} catch(_) {}
$('streamKeyInput').addEventListener('input', () => {
  updateGoLiveBtn();
  try { localStorage.setItem(YT_KEY_STORAGE, $('streamKeyInput').value); } catch(_) {}
});

function updateGoLiveBtn() {
  const hasKey = streamPlatform === 'twitch'
    ? !!$('twitchKeyInput').value.trim()
    : !!$('streamKeyInput').value.trim();
  const label = streamPlatform === 'twitch' ? 'Go Live on Twitch' : 'Go Live on YouTube';
  $('btnGoLiveLabel').textContent = label;
  $('btnGoLive').disabled = !state.connected || !hasKey;
}

document.querySelectorAll('.quality-pill').forEach(p => {
  p.addEventListener('click', () => {
    document.querySelectorAll('.quality-pill').forEach(x => x.classList.remove('active'));
    p.classList.add('active');
    state.quality = p.dataset.q;
  });
});

// ── Background Music (Radio) ──────────────────────────────────────────────
// SomaFM stations — continuous royalty-free streams, no API key, no restarts.
// Direct MP3 stream URLs confirmed working with FFmpeg.
const RADIO_STATIONS = [
  { id:'spacestation', name:'Space Station', genre:'Ambient / Space',    icon:'🛸', url:'https://ice2.somafm.com/spacestation-128-mp3' },
  { id:'groovesalad',  name:'Groove Salad',  genre:'Ambient / Electronic', icon:'🌿', url:'https://ice2.somafm.com/groovesalad-128-mp3' },
  { id:'deepspaceone', name:'Deep Space One', genre:'Deep Ambient',       icon:'🌌', url:'https://ice2.somafm.com/deepspaceone-128-mp3' },
  { id:'dronezone',    name:'Drone Zone',    genre:'Dark Ambient',        icon:'🔭', url:'https://ice2.somafm.com/dronezone-128-mp3' },
  { id:'lush',         name:'Lush',          genre:'Lush Downtempo',      icon:'🌸', url:'https://ice2.somafm.com/lush-128-mp3' },
  { id:'indiepop',     name:'Indie Pop',     genre:'Indie / Pop',         icon:'🎸', url:'https://ice2.somafm.com/indiepop-128-mp3' },
  { id:'cliqhop',      name:'Cliqhop',       genre:'IDM / Electronic',    icon:'⚡', url:'https://ice2.somafm.com/cliqhop-128-mp3' },
  { id:'sonicuniverse', name:'Sonic Universe', genre:'Jazz / Fusion',     icon:'🎷', url:'https://ice2.somafm.com/sonicuniverse-128-mp3' },
  { id:'beatblender',  name:'Beat Blender',  genre:'Downtempo / Hip-Hop', icon:'🎧', url:'https://ice2.somafm.com/beatblender-128-mp3' },
  { id:'folkfwd',      name:'Folk Forward',  genre:'Folk / Indie',        icon:'🪕', url:'https://ice2.somafm.com/folkfwd-128-mp3' },
  { id:'illstreet',    name:'Ill Street Blues', genre:'Blues / Jazz',     icon:'🎺', url:'https://ice2.somafm.com/illstreet-128-mp3' },
  { id:'thistle',      name:'Thistle Radio', genre:'Celtic / Folk',       icon:'🌾', url:'https://ice2.somafm.com/thistle-128-mp3' },
];

const music = {
  enabled:  false,
  track:    null,   // { name, genre, url }
  volume:   40,
};

// Render station grid
(function buildStationGrid() {
  const grid = $('radioStationGrid');
  if (!grid) return;
  RADIO_STATIONS.forEach(s => {
    const btn = document.createElement('button');
    btn.className   = 'radio-btn';
    btn.dataset.id  = s.id;
    btn.innerHTML   = `<span class="radio-btn-icon">${s.icon}</span>
                       <span class="radio-btn-name">${s.name}</span>
                       <span class="radio-btn-genre">${s.genre}</span>`;
    btn.addEventListener('click', () => {
      document.querySelectorAll('.radio-btn').forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      selectMusicTrack({ title: s.name, artist: s.genre, streamUrl: s.url });
    });
    grid.appendChild(btn);
  });
})();

$('musicEnabled').addEventListener('change', () => {
  music.enabled = $('musicEnabled').checked;
  $('musicPanel').classList.toggle('hidden', !music.enabled);
});

$('musicVolume').addEventListener('input', () => {
  music.volume = +$('musicVolume').value;
  $('musicVolumeVal').textContent = music.volume + '%';
  // Apply volume change live if streaming
  if (state.streaming && music.enabled && music.track) {
    api.setVolume(music.volume / 100);
  }
});

$('fmaLink').addEventListener('click', e => { e.preventDefault(); api.openExternal('https://somafm.com'); });

function selectMusicTrack(track) {
  music.track = track;
  $('musicTrackTitle').textContent  = track.title;
  $('musicTrackArtist').textContent = track.artist;
  $('musicNowPlaying').classList.remove('hidden');

  // If already streaming, switch the audio proxy instantly — no restart needed
  if (state.streaming && track.streamUrl) {
    api.switchRadio(track.streamUrl);
    toast(`♪ Switched to ${track.title}`, 'success');
  }
}

$('btnMusicClear').addEventListener('click', () => {
  music.track = null;
  $('musicNowPlaying').classList.add('hidden');
  document.querySelectorAll('.radio-btn').forEach(b => b.classList.remove('active'));
  // If streaming, switch proxy to silence (empty stream ends naturally, FFmpeg falls back to anullsrc isn't available mid-stream, so just notify)
  if (state.streaming) toast('Music removed — audio will go silent after current buffer', 'info');
});
// ── Go Live ────────────────────────────────────────────────────────────────
$('btnGoLive').addEventListener('click', async () => {
  if (!state.connected) { toast('Not connected to telescope', 'error'); return; }

  let streamKey, rtmpUrl;
  if (streamPlatform === 'twitch') {
    streamKey = $('twitchKeyInput').value.trim();
    if (!streamKey) { toast('Enter your Twitch stream key', 'error'); return; }
    rtmpUrl = `rtmp://live.twitch.tv/app/${streamKey}`;
  } else {
    streamKey = $('streamKeyInput').value.trim();
    if (!streamKey) { toast('Enter your YouTube stream key', 'error'); return; }
    rtmpUrl = null;
  }

  $('btnGoLive').disabled = true;
  $('btnGoLiveLabel').textContent = 'Starting…';
  toast(`Starting ${streamPlatform === 'twitch' ? 'Twitch' : 'YouTube'} stream…`, 'info');

  // Show connecting status in stream log
  appendStreamLog(`Connecting to ${streamPlatform === 'twitch' ? 'Twitch' : 'YouTube'}...\n`);
  if (streamPlatform === 'youtube') {
    appendStreamLog('Tip: In YouTube Studio → Stream → Streaming software — keep that page open. Once connected, click Go Live there to make it public.\n');
  }

  const r = await api.startStream({
    streamKey, rtmpUrl, telescopeIp: state.ip, quality: state.quality,
    musicUrl:    (music.enabled && music.track) ? music.track.streamUrl : null,
    musicVolume: music.volume,
  });

  if (!r.success) {
    $('btnGoLive').disabled = false;
    updateGoLiveBtn();
    toast(`Stream error: ${r.error}`, 'error');
    return;
  }

  // startStream resolved — FFmpeg is running. Force the UI to live state
  // in case stream:status IPC event was missed or arrived before this point
  if (!state.streaming) {
    handleStreamStatus({ live: true });
  }
});

$('btnStopLive').addEventListener('click', async () => {
  await api.stopStream();
  // Directly reset UI — don't rely solely on IPC event
  handleStreamStatus({ live: false });
});

function handleStreamStatus({ live, error }) {
  state.streaming = live;
  const badge = $('streamingBadge');
  if (live) {
    badge.textContent = 'LIVE'; badge.className = 'status-badge live';
    $('btnGoLive').disabled = false;  // re-enable in case it was stuck
    $('btnGoLive').classList.add('hidden');
    $('btnStopLive').classList.remove('hidden');
    const platformName = streamPlatform === 'twitch' ? 'Twitch' : 'YouTube';
    toast(`🔴 Live on ${platformName}!`, 'success');
  } else {
    badge.textContent = 'OFF'; badge.className = 'status-badge';
    $('btnGoLive').disabled = false;  // always re-enable when stream stops
    $('btnGoLive').classList.remove('hidden');
    $('btnStopLive').classList.add('hidden');
    updateGoLiveBtn();
    if (error) toast(`Stream ended: ${error}`, 'error');
  }
}

function appendStreamLog(msg) {
  const log = $('streamLog');
  if (log.querySelector('.log-dim')) log.innerHTML = '';
  const atBottom = log.scrollTop + log.clientHeight >= log.scrollHeight - 30;
  log.textContent += msg;
  if (atBottom) log.scrollTop = log.scrollHeight;
}

$('btnClearLog').addEventListener('click', () => {
  $('streamLog').innerHTML = '<span class="log-dim">Log cleared.</span>';
});

// ── Recording ──────────────────────────────────────────────────────────────
$('btnRecord').addEventListener('click', async () => {
  if (!state.connected) { toast('Not connected to telescope', 'error'); return; }

  const r = await api.startRecording({ telescopeIp:state.ip, quality:state.quality });
  if (r.canceled) return;
  if (!r.success) { toast(`Recording failed: ${r.error}`, 'error'); return; }
  // UI updated via handleRecordStatus
});

$('btnStopRecord').addEventListener('click', async () => {
  await api.stopRecording();
});

$('btnRevealRec').addEventListener('click', () => {
  if (state.recFilePath) api.revealFile(state.recFilePath);
});

function handleRecordStatus({ recording, filePath, saved, error }) {
  state.recording = recording;
  const badge = $('recordingBadge');
  const ind   = $('recIndicator');

  if (recording) {
    state.recFilePath = filePath;
    badge.textContent = 'REC'; badge.className = 'status-badge rec';
    ind.classList.remove('hidden');
    $('recFilePath').textContent = filePath || '';
    $('btnRecord').classList.add('hidden');
    $('btnStopRecord').classList.remove('hidden');
    toast('● Recording started', 'success');
  } else {
    badge.textContent = 'OFF'; badge.className = 'status-badge';
    ind.classList.add('hidden');
    $('btnRecord').classList.remove('hidden');
    $('btnStopRecord').classList.add('hidden');
    if (saved) toast(`Recording saved to ${saved.split('\\').pop()}`, 'success', 5000);
    if (error) toast(`Recording error: ${error}`, 'error');
  }
}

// ── Port scanner (diagnostic) ──────────────────────────────────────────────
$('btnScanPorts').addEventListener('click', async () => {
  const panel = $('streamDebugPanel');
  // If panel is visible, just hide it (toggle)
  if (!panel.classList.contains('hidden')) {
    panel.classList.add('hidden');
    return;
  }
  if (!state.connected) { toast('Connect to telescope first', 'error'); return; }
  panel.classList.remove('hidden');
  const log = $('streamDebugLog');
  log.textContent = `Scanning ports on ${state.ip}...\n`;
  const ports = await api.scanPorts(state.ip);
  log.textContent += `Open ports: ${ports.length ? ports.join(', ') : 'none found'}\n`;
  log.textContent += `\nNow probing for video stream...\n`;
  await loadStream(state.ip);
});

$('btnClearDebug').addEventListener('click', () => {
  $('streamDebugLog').textContent = '';
});

$('btnHideDiag').addEventListener('click', () => {
  $('streamDebugPanel').classList.add('hidden');
});

// Listen for debug messages from main process
api.onDebug(msg => {
  const log = $('streamDebugLog');
  log.textContent += msg + '\n';
  log.scrollTop = log.scrollHeight;
  // Only show panel if it has been explicitly opened (not hidden)
  // Don't auto-show on debug messages — user must click Scan Ports
});

// ── Snapshot ───────────────────────────────────────────────────────────────
$('btnSnapshot').addEventListener('click', async () => {
  if (!state.connected) { toast('Not connected', 'error'); return; }
  const r = await api.snapshot({ telescopeIp: state.ip });
  if (r.canceled) return;
  if (r.success) toast(`Snapshot saved: ${r.filePath.split('\\').pop()}`, 'success');
  else toast(`Snapshot failed: ${r.error}`, 'error');
});

// ── FFmpeg check ───────────────────────────────────────────────────────────
async function checkFFmpeg() {
  const r  = await api.checkFFmpeg();
  const el = $('ffmpegStatus'), el2 = $('ffmpegSettingsStatus');
  if (r.available) {
    el.innerHTML  = `<div class="ffmpeg-ok">✓ FFmpeg ${r.version} — ready</div>`;
    if (el2) el2.innerHTML = `<span style="color:var(--green);font-family:var(--mono);font-size:12px">✓ FFmpeg ${r.version} found in PATH</span>`;
  } else {
    el.innerHTML  = '<div class="ffmpeg-missing">⚠ FFmpeg not found — streaming &amp; recording require it</div>';
    if (el2) el2.innerHTML = '<span style="color:var(--red);font-size:12px">✗ FFmpeg not found. Install and add to PATH, then restart.</span>';
  }
}

// ── Mount D-Pad ────────────────────────────────────────────────────────────
document.querySelectorAll('.speed-pill').forEach(p => {
  p.addEventListener('click', () => {
    document.querySelectorAll('.speed-pill').forEach(x => x.classList.remove('active'));
    p.classList.add('active');
    state.slewSpeed = +p.dataset.speed;
  });
});

['North','South','East','West'].forEach(dir => {
  const btn = $(`btn${dir}`);
  const d   = dir.toLowerCase();
  btn.addEventListener('mousedown',  () => slew(d));
  btn.addEventListener('mouseup',    stopSlew);
  btn.addEventListener('mouseleave', stopSlew);
  btn.addEventListener('touchstart', e => { e.preventDefault(); slew(d); });
  btn.addEventListener('touchend',   stopSlew);
});

function slew(direction) {
  if (!state.connected) { toast('Not connected', 'error'); return; }
  api.command({ ip:state.ip, command:'movingrate', params:{ Direction:direction, Rate:state.slewSpeed } });
}
function stopSlew() {
  if (!state.connected) return;
  api.command({ ip:state.ip, command:'abortslew', params:{} });
}

$('btnStop').addEventListener('click', () => {
  if (!state.connected) return;
  api.command({ ip:state.ip, command:'abortslew', params:{} });
  toast('Slew aborted', 'info');
});

$('btnTrackSidereal').addEventListener('click', () => {
  if (!state.connected) { toast('Not connected', 'error'); return; }
  api.command({ ip:state.ip, command:'tracking', params:{ Tracking:true } });
  $('trackingBadge').textContent = 'ON';
  $('trackingBadge').className   = 'status-badge on';
  toast('Sidereal tracking enabled', 'success');
});

$('btnTrackOff').addEventListener('click', () => {
  if (!state.connected) { toast('Not connected', 'error'); return; }
  api.command({ ip:state.ip, command:'tracking', params:{ Tracking:false } });
  $('trackingBadge').textContent = 'OFF';
  $('trackingBadge').className   = 'status-badge';
  toast('Tracking stopped', 'info');
});

$('btnParkMount').addEventListener('click', () => {
  if (!state.connected) { toast('Not connected', 'error'); return; }
  api.command({ ip:state.ip, command:'park', params:{} });
  toast('Parking mount…', 'info');
});

$('btnEmergStop').addEventListener('click', () => {
  if (!state.connected) { toast('Not connected', 'error'); return; }
  api.command({ ip:state.ip, command:'abortslew', params:{} });
  api.command({ ip:state.ip, command:'tracking',  params:{ Tracking:false } });
  toast('⚠ Emergency stop!', 'error');
});

// ── Initialize ─────────────────────────────────────────────────────────────
let initRunning = false;
let initSeq = 0; // increments each time we click init, so stale STOPPED events are ignored

$('btnInitialize').addEventListener('click', async () => {
  if (!state.connected) { toast('Not connected', 'error'); return; }
  if (!confirm('Run Initialize? This will run the full startup sequence (battery check, calibration, flat/dark generation). Make sure the telescope is indoors with the lens cap on.')) return;
  runInitialize(false);
});

$('btnInitializeDemo').addEventListener('click', async () => {
  if (!state.connected) { toast('Not connected', 'error'); return; }
  if (!confirm('Run Demo Mode Initialize? This skips the sun-above-horizon check so you can test during the day. The telescope should still have its lens cap on.')) return;
  runInitialize(true);
});

async function runInitialize(demoMode) {
  // First set initRunning = false briefly so any queued STOPPED events from
  // a previous attempt are ignored by the onTaskStatus handler
  initRunning = false;
  $('btnInitialize').disabled = true;
  $('btnInitializeDemo').disabled = true;
  $('btnInitialize').textContent = '⚙ Initializing…';
  $('initStatus').textContent = `⏳ Sending${demoMode ? ' demo mode' : ''} command…`;
  $('initStatus').style.color = 'var(--accent)';

  // Small delay to let any pending STOPPED events flush through before we set initRunning = true
  await new Promise(r => setTimeout(r, 200));
  initRunning = true;

  const r = await api.command({ ip:state.ip, command:'initialize', params:{
    Latitude:  state.userLat,
    Longitude: state.userLon,
    DemoMode:  demoMode,
  }});

  // The RunInitialize response tells us immediately if it failed
  if (r && r.ErrorCode !== undefined && r.ErrorCode !== 0) {
    initRunning = false;
    $('btnInitialize').disabled = false;
    $('btnInitializeDemo').disabled = false;
    $('btnInitialize').textContent = '⚙ Initialize Telescope';
    const errMsg = r.ErrorMessage || 'Initialization failed';
    $('initStatus').textContent = `⚠ ${errMsg}`;
    $('initStatus').style.color = 'var(--red)';
    toast(errMsg, 'error');
    return;
  }

  // Command sent OK — telescope will broadcast TaskController status as it runs
  $('initStatus').textContent = `⚙ Initialization running${demoMode ? ' (demo mode)' : ''}…`;
  toast(`✓ Initialization${demoMode ? ' (demo mode)' : ''} started`, 'info');

  // Safety: re-enable after 5 minutes (full init takes ~3 min)
  // The onTaskStatus handler will resolve this earlier when complete
  setTimeout(() => {
    if (initRunning) {
      initRunning = false;
      $('btnInitialize').disabled = false;
      $('btnInitializeDemo').disabled = false;
      $('btnInitialize').textContent = '⚙ Initialize Telescope';
      $('initStatus').textContent = '⚠ Initialization timed out';
      $('initStatus').style.color = 'var(--red)';
    }
  }, 300000); // 5 minutes
}

// Listen for TaskController status broadcasts — shows current init phase
const PHASE_LABELS = {
  'IDLE':                 '✓ Idle — ready',
  'BATTERY':              '🔋 Checking battery…',
  'UPDATE':               '📡 Checking for updates…',
  'HARDWARE_CALIBRATION': '⚙ Hardware calibration…',
  'DARK_GENERATION':      '🌑 Generating dark frames…',
  'FLAT_GENERATION':      '💡 Generating flat frames…',
  'FA_TEST':              '🔭 Focus test…',
  'FINALIZATION':         '✅ Finalizing…',
  'GOTO':                 '🎯 Slewing to target…',
  'AUTO':                 '📸 Stacking images…',
  'MANUAL':               '📷 Manual capture…',
  'PARK':                 '🏠 Parking…',
};

// ── Image type badge + stacking overlay ────────────────────────────────────
let stackFrameCount = 0;
let stackTotalTime  = 0;

function resetStackCounter() {
  stackFrameCount = 0;
  stackTotalTime  = 0;
  if ($('stackFrames')) $('stackFrames').textContent = '0';
  if ($('stackTime'))   $('stackTime').textContent   = '0s';
}

function showStackingOverlay(show) {
  const el = $('stackingOverlay');
  if (el) el.style.display = show ? 'block' : 'none';
}

api.onImageType(imgType => {
  const badge = $('imageModeBadge');
  if (badge) {
    badge.textContent = imgType;
    badge.className = imgType === 'STACKED' ? 'status-badge on' : 'status-badge';
  }
  showStackingOverlay(imgType === 'STACKED');
  if (imgType !== 'STACKED') resetStackCounter();
});

api.onImageMeta(meta => {
  if (meta.imageType !== 'STACKED') return;
  stackFrameCount++;
  stackTotalTime += meta.exposureTime || 0;
  if ($('stackFrames')) $('stackFrames').textContent = stackFrameCount;
  if ($('stackTime')) {
    const t = stackTotalTime;
    $('stackTime').textContent = t >= 60
      ? `${Math.floor(t/60)}m ${Math.round(t%60)}s`
      : `${t.toFixed(1)}s`;
  }
  // Update target name from GoTo target if set
  if (state.gotoTarget && $('stackTarget')) {
    $('stackTarget').textContent = state.gotoTarget;
  }
});

api.onTaskStatus(msg => {
  const state_ = msg.State || 'IDLE';
  const stage  = msg.Stage || 'IN_PROGRESS';
  const err    = msg.ErrorMessage || '';

  // Only log non-IDLE states — IDLE broadcasts every second and floods the log
  if (state_ !== 'IDLE' || err) {
    appendStreamLog(`[TaskCtrl] State=${state_} Stage=${stage}${err ? ' Err='+err : ''}`);
  }

  if (state_ === 'INITIALIZING' && stage === 'IN_PROGRESS') {
    if (initRunning) {
      $('initStatus').textContent = '⚙ Initialization running…';
      $('btnInitialize').textContent = '⚙ Initializing…';
    }
  } else if (state_ === 'INITIALIZING' && stage === 'STOPPED') {
    // Only react to STOPPED if this is still our current run
    // (ignore stale STOPPED from a previous regular-init attempt while demo is running)
    if (initRunning) {
      initRunning = false;
      $('btnInitialize').disabled = false;
      $('btnInitializeDemo').disabled = false;
      $('btnInitialize').textContent = '⚙ Initialize Telescope';
      const errMsg = err || 'Initialization stopped';
      $('initStatus').textContent = `⚠ ${errMsg}`;
      $('initStatus').style.color = 'var(--red)';
      toast(errMsg, 'error');
    }
    // If !initRunning: stale STOPPED from a previous attempt — ignore completely
  } else if (stage === 'COMPLETE') {
    if (initRunning) {
      initRunning = false;
      $('btnInitialize').disabled = false;
      $('btnInitializeDemo').disabled = false;
      $('btnInitialize').textContent = '⚙ Initialize Telescope';
      $('initStatus').textContent = '✓ Initialization complete — telescope ready';
      $('initStatus').style.color = 'var(--accent)';
      toast('✓ Telescope initialized and ready!', 'success');
    }
  } else if (state_ === 'IDLE' && initRunning) {
    initRunning = false;
    $('btnInitialize').disabled = false;
    $('btnInitializeDemo').disabled = false;
    $('btnInitialize').textContent = '⚙ Initialize Telescope';
    $('initStatus').textContent = '✓ Initialization complete — telescope ready';
    $('initStatus').style.color = 'var(--accent)';
    toast('✓ Telescope initialized and ready!', 'success');
  }

  // Stacking status — driven by State field
  if (state_ === 'AUTO') {
    $('stackingStatus').textContent = '● Stacking active — images being stacked';
    $('stackingStatus').style.color = 'var(--accent)';
    if ($('imageModeBadge')) { $('imageModeBadge').textContent = 'STACKED'; $('imageModeBadge').className = 'status-badge on'; }
    showStackingOverlay(true);
  } else if ($('stackingStatus').textContent.includes('Stacking active')) {
    $('stackingStatus').textContent = 'Not stacking — live view active';
    $('stackingStatus').style.color = '';
    if ($('imageModeBadge')) { $('imageModeBadge').textContent = 'LIVE'; $('imageModeBadge').className = 'status-badge'; }
    showStackingOverlay(false);
    resetStackCounter();
  }
});

// ── Image Stacking ──────────────────────────────────────────────────────────
$('btnStartStacking').addEventListener('click', async () => {
  if (!state.connected) { toast('Not connected', 'error'); return; }
  $('btnStartStacking').disabled = true;
  $('stackingStatus').textContent = 'Starting stacking…';
  await api.command({ ip:state.ip, command:'startauto', params:{} });
  $('btnStartStacking').disabled = false;
  resetStackCounter();
  // Status will update via TaskController broadcast when State→AUTO
  // or via NewImageReady when ImageType→STACKED
  toast('✓ Stacking command sent', 'success');
});

$('btnStopStacking').addEventListener('click', async () => {
  if (!state.connected) { toast('Not connected', 'error'); return; }
  $('btnStopStacking').disabled = true;
  $('stackingStatus').textContent = 'Stopping stacking…';
  await api.command({ ip:state.ip, command:'stopauto', params:{} });
  $('btnStopStacking').disabled = false;
  $('stackingStatus').textContent = 'Not stacking — live view active';
  $('stackingStatus').style.color = '';
  if ($('imageModeBadge')) {
    $('imageModeBadge').textContent = 'LIVE';
    $('imageModeBadge').className = 'status-badge';
  }
  toast('Stacking stopped', 'info');
});


$('btnGoto').addEventListener('click', () => {
  if (!state.connected) { toast('Not connected', 'error'); return; }
  const ra  = $('gotoRA').value.trim();
  const dec = $('gotoDec').value.trim();
  if (!ra || !dec) { toast('Enter RA and Dec', 'error'); return; }
  state.gotoTarget = `RA ${ra} Dec ${dec}`;
  if ($('stackTarget')) $('stackTarget').textContent = state.gotoTarget;
  api.command({ ip:state.ip, command:'slewtocoordinates', params:{ RightAscension:parseCoord(ra), Declination:parseCoord(dec,true) } });
  toast(`Slewing to RA ${ra}, Dec ${dec}`, 'info');
});

function parseCoord(str, isDec=false) {
  const parts = str.trim().split(/[\s:hmdHMD°'"]+/).filter(Boolean);
  const sign  = str.trim().startsWith('-') ? -1 : 1;
  const d = +parts[0]||0, m = +parts[1]||0, s = +parts[2]||0;
  return sign * (Math.abs(d) + m/60 + s/3600);
}

// ── Tonight's Best Targets ─────────────────────────────────────────────────
// Deep sky object catalog: { name, type, ra (hours), dec (degrees), mag, desc }
const DSO_CATALOG = [
  // Nebulae
  { name:'M42',  type:'Nebula',   icon:'🌌', ra:5.588,  dec:-5.39,  mag:4.0,  desc:'Orion Nebula' },
  { name:'M1',   type:'Nebula',   icon:'💥', ra:5.575,  dec:22.01,  mag:8.4,  desc:'Crab Nebula' },
  { name:'M8',   type:'Nebula',   icon:'🌌', ra:18.063, dec:-24.38, mag:6.0,  desc:'Lagoon Nebula' },
  { name:'M17',  type:'Nebula',   icon:'🌌', ra:18.346, dec:-16.18, mag:6.0,  desc:'Omega Nebula' },
  { name:'M20',  type:'Nebula',   icon:'🌌', ra:18.033, dec:-23.03, mag:6.3,  desc:'Trifid Nebula' },
  { name:'M27',  type:'Nebula',   icon:'💫', ra:19.994, dec:22.72,  mag:7.4,  desc:'Dumbbell Nebula' },
  { name:'M57',  type:'Nebula',   icon:'💫', ra:18.893, dec:33.03,  mag:8.8,  desc:'Ring Nebula' },
  { name:'M97',  type:'Nebula',   icon:'💫', ra:11.246, dec:55.02,  mag:9.9,  desc:'Owl Nebula' },
  { name:'NGC 7293', type:'Nebula', icon:'💫', ra:22.495, dec:-20.84, mag:7.3, desc:'Helix Nebula' },
  { name:'NGC 7009', type:'Nebula', icon:'💫', ra:21.073, dec:-11.36, mag:8.0, desc:'Saturn Nebula' },
  // Galaxies
  { name:'M31',  type:'Galaxy',   icon:'🌀', ra:0.712,  dec:41.27,  mag:3.4,  desc:'Andromeda Galaxy' },
  { name:'M33',  type:'Galaxy',   icon:'🌀', ra:1.564,  dec:30.66,  mag:5.7,  desc:'Triangulum Galaxy' },
  { name:'M51',  type:'Galaxy',   icon:'🌀', ra:13.497, dec:47.20,  mag:8.4,  desc:'Whirlpool Galaxy' },
  { name:'M81',  type:'Galaxy',   icon:'🌀', ra:9.926,  dec:69.07,  mag:6.9,  desc:'Bode\'s Galaxy' },
  { name:'M82',  type:'Galaxy',   icon:'🌀', ra:9.926,  dec:69.68,  mag:8.4,  desc:'Cigar Galaxy' },
  { name:'M101', type:'Galaxy',   icon:'🌀', ra:14.053, dec:54.35,  mag:7.9,  desc:'Pinwheel Galaxy' },
  { name:'M104', type:'Galaxy',   icon:'🌀', ra:12.666, dec:-11.62, mag:8.0,  desc:'Sombrero Galaxy' },
  { name:'M64',  type:'Galaxy',   icon:'🌀', ra:12.945, dec:21.68,  mag:8.5,  desc:'Black Eye Galaxy' },
  { name:'NGC 891', type:'Galaxy', icon:'🌀', ra:2.375,  dec:42.35,  mag:9.9, desc:'Edge-on Galaxy' },
  { name:'NGC 253', type:'Galaxy', icon:'🌀', ra:0.793,  dec:-25.29, mag:7.6, desc:'Sculptor Galaxy' },
  // Clusters
  { name:'M45',  type:'Cluster',  icon:'✨', ra:3.790,  dec:24.12,  mag:1.6,  desc:'Pleiades' },
  { name:'M13',  type:'Cluster',  icon:'✨', ra:16.695, dec:36.46,  mag:5.8,  desc:'Hercules Cluster' },
  { name:'M3',   type:'Cluster',  icon:'✨', ra:13.703, dec:28.38,  mag:6.2,  desc:'Globular Cluster' },
  { name:'M5',   type:'Cluster',  icon:'✨', ra:15.309, dec:2.08,   mag:5.6,  desc:'Globular Cluster' },
  { name:'M92',  type:'Cluster',  icon:'✨', ra:17.285, dec:43.14,  mag:6.4,  desc:'Globular Cluster' },
  { name:'M35',  type:'Cluster',  icon:'✨', ra:6.148,  dec:24.35,  mag:5.1,  desc:'Open Cluster' },
  { name:'M44',  type:'Cluster',  icon:'✨', ra:8.673,  dec:19.98,  mag:3.7,  desc:'Beehive Cluster' },
  { name:'NGC 869', type:'Cluster', icon:'✨', ra:2.319, dec:57.13, mag:5.3,  desc:'Double Cluster h Per' },
  { name:'NGC 884', type:'Cluster', icon:'✨', ra:2.370, dec:57.14, mag:6.1,  desc:'Double Cluster χ Per' },
  // Bright showpieces
  { name:'M15',  type:'Cluster',  icon:'✨', ra:21.500, dec:12.17,  mag:6.2,  desc:'Globular Cluster' },
  { name:'M22',  type:'Cluster',  icon:'✨', ra:18.607, dec:-23.90, mag:5.1,  desc:'Sagittarius Cluster' },
  { name:'M11',  type:'Cluster',  icon:'✨', ra:18.851, dec:-6.27,  mag:5.8,  desc:'Wild Duck Cluster' },
];

function calcAltAz(raHours, decDeg, latDeg, lonDeg, date) {
  const D2R = Math.PI / 180;
  const R2D = 180 / Math.PI;
  // Julian date
  const jd = date.getTime() / 86400000 + 2440587.5;
  const T  = (jd - 2451545.0) / 36525;
  // Greenwich Mean Sidereal Time (degrees)
  let gmst = 280.46061837 + 360.98564736629 * (jd - 2451545.0)
           + 0.000387933 * T * T - T * T * T / 38710000;
  gmst = ((gmst % 360) + 360) % 360;
  // Local Sidereal Time
  const lst = ((gmst + lonDeg) % 360 + 360) % 360;
  // Hour Angle
  const ha  = (lst - raHours * 15 + 360) % 360;
  const haR = ha * D2R, decR = decDeg * D2R, latR = latDeg * D2R;
  // Altitude
  const sinAlt = Math.sin(decR) * Math.sin(latR) + Math.cos(decR) * Math.cos(latR) * Math.cos(haR);
  const alt = Math.asin(Math.max(-1, Math.min(1, sinAlt))) * R2D;
  return Math.round(alt);
}

function getTonightTargets(latDeg, lonDeg) {
  const now  = new Date();
  const targets = DSO_CATALOG.map(obj => {
    const alt = calcAltAz(obj.ra, obj.dec, latDeg, lonDeg, now);
    return { ...obj, alt };
  })
  .filter(t => t.alt > 20)            // above 20° horizon
  .sort((a, b) => b.alt - a.alt)      // highest first
  .slice(0, 12);                       // top 12
  return targets;
}

function renderTonightTargets(lat, lon, locationName) {
  const targets = getTonightTargets(lat, lon);

  // Update both the Mount Control panel and the Live View panel
  const locLabel    = $('targetsLocation');
  const lvLocLabel  = $('liveViewTargetsLocation');
  const locText     = locationName || `${lat.toFixed(1)}°, ${lon.toFixed(1)}°`;
  if (locLabel)   locLabel.textContent   = `· ${locText}`;
  if (lvLocLabel) lvLocLabel.textContent = `· ${locText}`;

  // ── Mount Control full list ──────────────────────────────────────────────
  const container = $('tonightTargets');
  if (container) {
    if (!targets.length) {
      container.innerHTML = '<span class="log-dim" style="font-size:11px;padding:8px 0;display:block">No objects above 20° right now — check back after dark.</span>';
    } else {
      container.innerHTML = '';
      targets.forEach(t => {
        const quality = t.alt > 50 ? 'great' : 'good';
        const btn = document.createElement('button');
        btn.className = 'target-tonight';
        btn.innerHTML = `
          <span class="target-tonight-icon">${t.icon}</span>
          <span class="target-tonight-info">
            <span class="target-tonight-name">${t.name} — ${t.desc}</span>
            <span class="target-tonight-meta">${t.type} · Mag ${t.mag}</span>
          </span>
          <span class="target-tonight-alt">${t.alt}°</span>
          <span class="target-tonight-badge badge-${quality}">${quality}</span>`;
        btn.addEventListener('click', () => {
          if (!state.connected) { toast('Connect telescope first', 'error'); return; }
          state.gotoTarget = t.name;
          if ($('stackTarget')) $('stackTarget').textContent = t.name;
          api.command({ ip: state.ip, command: 'slewtoobject', params: { Target: t.name } });
          toast(`Slewing to ${t.name} (${t.desc})…`, 'info');
        });
        container.appendChild(btn);
      });
      $('btnRefreshTargets').style.display = 'block';
    }
  }

  // ── Live View compact list (top 6) ───────────────────────────────────────
  const lvContainer = $('liveViewTargets');
  if (lvContainer) {
    if (!targets.length) {
      lvContainer.innerHTML = '<span class="log-dim" style="font-size:11px">No objects visible right now.</span>';
    } else {
      lvContainer.innerHTML = '';
      targets.slice(0, 6).forEach(t => {
        const btn = document.createElement('button');
        btn.className = 'liveview-target-btn';
        btn.innerHTML = `
          <span class="liveview-target-icon">${t.icon}</span>
          <span class="liveview-target-name">${t.name} ${t.desc}</span>
          <span class="liveview-target-alt">${t.alt}°</span>`;
        btn.addEventListener('click', () => {
          if (!state.connected) { toast('Connect telescope first', 'error'); return; }
          state.gotoTarget = t.name;
          if ($('stackTarget')) $('stackTarget').textContent = t.name;
          api.command({ ip: state.ip, command: 'slewtoobject', params: { Target: t.name } });
          toast(`Slewing to ${t.name} (${t.desc})…`, 'info');
        });
        lvContainer.appendChild(btn);
      });
    }
  }
}

$('btnRefreshTargets').addEventListener('click', () => {
  if (state.userLat !== undefined) renderTonightTargets(state.userLat, state.userLon, state.locationName);
});

// Listen for location from telescope's live WebSocket (Mount GetStatus fires every second)
// Location updates handled in Viewing Conditions section below

// Load tonight's targets — check saved location first, then wait for telescope to broadcast it
function loadTonightTargets() {
  api.getLocation().then(loc => {
    if (loc?.lat !== undefined) {
      state.userLat      = loc.lat;
      state.userLon      = loc.lon;
      state.locationName = loc.city || '';
      renderTonightTargets(state.userLat, state.userLon, state.locationName);
      // Also load weather conditions if not already loaded
      if (!weatherRefreshTimer) loadViewingConditions(loc.lat, loc.lon);
    } else {
      // No saved location yet — show waiting message, onLocation will update when telescope broadcasts
      const waiting = '<span class="log-dim" style="font-size:11px;padding:8px 0;display:block;line-height:1.6">Waiting for telescope GPS…<br><small>Location is read automatically from the telescope\'s mount status.</small></span>';
      const mc = $('tonightTargets');
      const lv = $('liveViewTargets');
      if (mc) mc.innerHTML = waiting;
      if (lv) lv.innerHTML = '<span class="log-dim" style="font-size:11px">Waiting for GPS…</span>';
    }
  });
}

// Load targets when the mount control tab is shown

// ── Viewing Conditions ─────────────────────────────────────────────────────
// Fetches current weather from Open-Meteo (free, no API key) and rates
// viewing conditions for astronomy based on cloud cover, humidity, wind, etc.

// WMO weather code descriptions relevant to astronomy
const WMO_CODES = {
  0:'Clear sky', 1:'Mainly clear', 2:'Partly cloudy', 3:'Overcast',
  45:'Foggy', 48:'Icy fog', 51:'Light drizzle', 53:'Drizzle',
  55:'Heavy drizzle', 61:'Light rain', 63:'Rain', 65:'Heavy rain',
  71:'Light snow', 73:'Snow', 75:'Heavy snow', 77:'Snow grains',
  80:'Rain showers', 81:'Rain showers', 82:'Heavy showers',
  85:'Snow showers', 86:'Heavy snow showers',
  95:'Thunderstorm', 96:'Thunderstorm w/ hail', 99:'Thunderstorm w/ hail',
};

function calcViewingScore(w) {
  // Returns { score: 0-100, rating: string, color: string, factors: [] }
  if (!w) return null;
  let score = 100;
  const factors = [];

  // Cloud cover (0-100%) — biggest factor
  const cloud = w.cloud_cover ?? 0;
  if (cloud <= 10) {
    factors.push({ icon: '☁', text: `Cloud cover ${cloud}%`, good: true });
  } else if (cloud <= 30) {
    score -= 20;
    factors.push({ icon: '☁', text: `Cloud cover ${cloud}%`, good: true });
  } else if (cloud <= 60) {
    score -= 50;
    factors.push({ icon: '☁', text: `Cloud cover ${cloud}%`, good: false });
  } else {
    score -= 80;
    factors.push({ icon: '☁', text: `Cloud cover ${cloud}%`, good: false });
  }

  // Precipitation — ruins viewing
  const precip = w.precipitation ?? 0;
  if (precip > 0) {
    score -= 60;
    factors.push({ icon: '🌧', text: `Precipitation ${precip}mm`, good: false });
  } else {
    factors.push({ icon: '🌧', text: 'No precipitation', good: true });
  }

  // Humidity vs dew point — dew risk
  const humidity = w.relative_humidity_2m ?? 0;
  const temp     = w.temperature_2m ?? 50;
  const dewPoint = w.dew_point_2m ?? 0;
  const dewGap   = temp - dewPoint;
  if (dewGap < 3) {
    score -= 30;
    factors.push({ icon: '💧', text: `Dew risk — gap only ${dewGap.toFixed(1)}°F`, good: false });
  } else if (dewGap < 8) {
    score -= 10;
    factors.push({ icon: '💧', text: `Humidity ${humidity}% — low dew risk`, good: true });
  } else {
    factors.push({ icon: '💧', text: `Humidity ${humidity}% — no dew risk`, good: true });
  }

  // Wind speed (mph)
  const wind = w.wind_speed_10m ?? 0;
  const gusts = w.wind_gusts_10m ?? 0;
  if (wind <= 5) {
    factors.push({ icon: '🌬', text: `Wind ${wind.toFixed(0)} mph — calm`, good: true });
  } else if (wind <= 12) {
    score -= 10;
    factors.push({ icon: '🌬', text: `Wind ${wind.toFixed(0)} mph — mild`, good: true });
  } else if (wind <= 20) {
    score -= 25;
    factors.push({ icon: '🌬', text: `Wind ${wind.toFixed(0)} mph — moderate`, good: false });
  } else {
    score -= 40;
    factors.push({ icon: '🌬', text: `Wind ${wind.toFixed(0)} mph — strong`, good: false });
  }

  // Visibility (metres)
  const vis = w.visibility ?? 24000;
  if (vis >= 16000) {
    factors.push({ icon: '👁', text: `Visibility ${(vis/1609).toFixed(0)} mi — excellent`, good: true });
  } else if (vis >= 8000) {
    score -= 10;
    factors.push({ icon: '👁', text: `Visibility ${(vis/1609).toFixed(1)} mi — good`, good: true });
  } else {
    score -= 30;
    factors.push({ icon: '👁', text: `Visibility ${(vis/1609).toFixed(1)} mi — poor`, good: false });
  }

  score = Math.max(0, Math.min(100, score));

  let rating, color;
  if (score >= 80)      { rating = 'Excellent'; color = '#4caf50'; }
  else if (score >= 60) { rating = 'Good';      color = '#8bc34a'; }
  else if (score >= 40) { rating = 'Fair';      color = '#ff9800'; }
  else if (score >= 20) { rating = 'Poor';      color = '#f44336'; }
  else                  { rating = 'Bad';       color = '#9c27b0'; }

  return { score, rating, color, factors };
}

function renderViewingConditions(w, units) {
  const body = $('viewingConditionsBody');
  if (!body) return;

  const result = calcViewingScore(w);
  if (!result) { body.innerHTML = '<span class="log-dim" style="font-size:11px">No data</span>'; return; }

  const wmoDesc = WMO_CODES[w.weather_code] || 'Unknown';
  const arcSize  = 54;
  const cx = arcSize/2, cy = arcSize/2, r = arcSize/2 - 5;
  const circumference = 2 * Math.PI * r;
  const dashOffset = circumference * (1 - result.score / 100);

  body.innerHTML = `
    <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
      <svg width="${arcSize}" height="${arcSize}" style="flex-shrink:0">
        <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="#1e2a3a" stroke-width="5"/>
        <circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${result.color}" stroke-width="5"
          stroke-dasharray="${circumference}" stroke-dashoffset="${dashOffset}"
          transform="rotate(-90 ${cx} ${cy})" stroke-linecap="round"/>
        <text x="${cx}" y="${cy+1}" text-anchor="middle" dominant-baseline="middle"
          fill="${result.color}" font-size="12" font-weight="bold" font-family="monospace">${result.score}</text>
      </svg>
      <div>
        <div style="font-size:14px;font-weight:700;color:${result.color}">${result.rating}</div>
        <div style="font-size:10px;color:var(--text-dim)">${wmoDesc}</div>
        <div style="font-size:10px;color:var(--text-dim)">${w.temperature_2m?.toFixed(0)}°F · ${w.time ? w.time.replace('T',' ') : ''}</div>
      </div>
    </div>
    <div style="display:flex;flex-direction:column;gap:3px">
      ${result.factors.map(f => `
        <div style="display:flex;align-items:center;gap:5px;font-size:10px">
          <span>${f.icon}</span>
          <span style="color:${f.good ? 'var(--text)' : '#f44336'}">${f.text}</span>
          <span style="margin-left:auto;font-size:9px">${f.good ? '✓' : '✗'}</span>
        </div>`).join('')}
    </div>`;
}

let weatherRefreshTimer = null;

function loadViewingConditions(lat, lon) {
  const body = $('viewingConditionsBody');
  const btn  = $('btnRefreshWeather');
  if (!body) return;
  body.innerHTML = '<span class="log-dim" style="font-size:11px">Fetching weather…</span>';
  if (btn) btn.disabled = true;

  api.getWeather(lat, lon).then(r => {
    if (btn) btn.disabled = false;
    if (r.success) {
      renderViewingConditions(r.data, r.units);
      // Auto-refresh every 15 minutes
      if (weatherRefreshTimer) clearTimeout(weatherRefreshTimer);
      weatherRefreshTimer = setTimeout(() => loadViewingConditions(lat, lon), 15 * 60 * 1000);
    } else {
      body.innerHTML = `<span class="log-dim" style="font-size:11px;color:var(--red)">Weather unavailable: ${r.error}</span>`;
    }
  });
}

$('btnRefreshWeather').addEventListener('click', () => {
  if (state.userLat !== undefined) loadViewingConditions(state.userLat, state.userLon);
});

// Auto-load weather when location becomes known
const _origOnLocation = api.onLocation;
api.onLocation(loc => {
  if (!loc?.lat) return;
  state.userLat = loc.lat; state.userLon = loc.lon; state.locationName = loc.city || '';
  renderTonightTargets(state.userLat, state.userLon, state.locationName);
  try {
    if ($('locationLat')) $('locationLat').value = loc.lat.toFixed(4);
    if ($('locationLon')) $('locationLon').value = loc.lon.toFixed(4);
    if ($('locationStatus')) $('locationStatus').textContent = `✓ From telescope: ${loc.lat.toFixed(2)}°, ${loc.lon.toFixed(2)}°`;
  } catch(_) {}
  // Load weather once we have location
  if (!weatherRefreshTimer) loadViewingConditions(loc.lat, loc.lon);
});





// ── Focus & Camera ─────────────────────────────────────────────────────────
$('btnFocusIn').addEventListener('click',  () => { if (!state.connected) return; api.command({ ip:state.ip, command:'focuser/move', params:{ Position:-$('focusSlider').value*100 } }); });
$('btnFocusOut').addEventListener('click', () => { if (!state.connected) return; api.command({ ip:state.ip, command:'focuser/move', params:{ Position: +$('focusSlider').value*100 } }); });
$('focusSlider').addEventListener('input', () => { $('focusVal').textContent = $('focusSlider').value; });
$('gainSlider').addEventListener('input',  () => { $('gainVal').textContent  = $('gainSlider').value;  if (state.connected) api.command({ ip:state.ip, command:'camera/gain',       params:{ Gain:+$('gainSlider').value } }); });
$('expSlider').addEventListener('input',   () => { $('expVal').textContent   = $('expSlider').value+'ms'; if (state.connected) api.command({ ip:state.ip, command:'camera/exposure',   params:{ ExposureTime:+$('expSlider').value } }); });
$('brightSlider').addEventListener('input',() => { $('brightVal').textContent= $('brightSlider').value;  if (state.connected) api.command({ ip:state.ip, command:'camera/brightness', params:{ Brightness:+$('brightSlider').value } }); });

// ── Telescope Settings Tab ─────────────────────────────────────────────────
function loadTelescopeSettings() {
  if (!state.connected) return;
  const setVal = (id, val, cls) => {
    const el = $(id);
    if (!el) return;
    el.textContent = val ?? '—';
    if (cls) el.className = `tele-val ${cls}`;
  };

  api.getAllSettings(state.ip).then(({ success, data }) => {
    if (!success || !data) return;

    const sys   = data['System:GetVersion']          || {};
    const model = data['System:GetModel']            || {};
    const upCh  = data['System:GetUpdateChannel']    || {};
    const upAvail = data['System:HasUpdateAvailable'] || {};
    const serial  = data['FactoryCalibrationController:GetSerialNumber'] || {};
    const cam   = data['Camera:GetCameraInfo']       || {};
    const capPar = data['Camera:GetCaptureParameters'] || {};
    const mnt   = data['Mount:GetMountConfig']       || {};
    const mntSt = data['Mount:GetStatus']            || {};
    const dew   = data['DewHeater:GetStatus']        || {};
    const env   = data['Environment:GetStatus']      || {};
    const foc   = data['Focuser:GetStatus']          || {};
    const focAdv = data['Focuser:GetFocuserAdvancedSettings'] || {};
    const focLim = data['Focuser:GetPositionLimits'] || {};
    const net   = data['Network:GetForceDirectConnect'] || {};
    const inet  = data['Network:HasInternetConnection'] || {};
    const led   = data['LedRing:GetBrightnessLevel'] || {};

    // System
    setVal('tsModel',     model.Value || 'Celestron Origin');
    setVal('tsFirmware',  sys.Number  || sys.Version?.split(' ')[0]);
    setVal('tsSerial',    serial.SerialNumber);
    setVal('tsCameraModel', cam.CameraModel);
    setVal('tsCameraFw',  cam.FirmwareVersion);
    setVal('tsUpdateChannel', upCh.Value);
    const updateAvail = upAvail.IsAvailableOnline;
    setVal('tsUpdateAvail', updateAvail ? '✓ Available' : 'Up to date',
           updateAvail ? 'warn' : 'good');

    // Camera
    setVal('tsSensor',     cam.CameraID?.replace('Origin178-', '') || cam.CameraModel);
    setVal('tsResolution', cam.MaxImageWidth && cam.MaxImageHeight ? `${cam.MaxImageWidth} × ${cam.MaxImageHeight}` : '—');
    setVal('tsPixelSize',  cam.PixelSize ? `${cam.PixelSize} µm` : '—');
    setVal('tsIsoRange',   cam.MinIso && cam.MaxIso ? `${cam.MinIso} – ${cam.MaxIso}` : '—');
    setVal('tsExpRange',   cam.MinExposure && cam.MaxExposure ? `${cam.MinExposure}s – ${cam.MaxExposure}s` : '—');
    setVal('tsColor',      cam.IsColor !== undefined ? (cam.IsColor ? 'Color' : 'Mono') : '—');
    setVal('tsBinning',    cam.MaxBinning ? `${cam.MaxBinning}×` : '—');
    setVal('tsWbR', capPar.ColorRBalance);
    setVal('tsWbG', capPar.ColorGBalance);
    setVal('tsWbB', capPar.ColorBBalance);

    // Mount
    setVal('tsMountName',   mnt.Name || 'Origin');
    const battLevel = mntSt.BatteryLevel;
    setVal('tsBattery', battLevel, battLevel === 'HIGH' ? 'good' : battLevel === 'LOW' ? 'bad' : 'warn');
    setVal('tsBattVolt',    mntSt.BatteryVoltage ? `${mntSt.BatteryVoltage.toFixed(2)}V` : '—');
    setVal('tsCharger',     mntSt.ChargerStatus);
    setVal('tsEquatorial',  mnt.IsEquatorial !== undefined ? (mnt.IsEquatorial ? 'Yes' : 'No') : '—');
    setVal('tsCordwrap',    mnt.IsCordwrapEnabled !== undefined ? (mnt.IsCordwrapEnabled ? 'Enabled' : 'Disabled') : '—');
    setVal('tsPec',         mnt.IsPecEnabled !== undefined ? (mnt.IsPecEnabled ? 'Enabled' : 'Disabled') : '—');
    setVal('tsAltBacklash', mnt.AltBacklash);
    setVal('tsAzmBacklash', mnt.AzmBacklash);

    // Extract location from Mount status (lat/lon in radians)
    if (mntSt.Latitude !== undefined && state.userLat === undefined) {
      const R2D = 180 / Math.PI;
      state.userLat = mntSt.Latitude * R2D;
      state.userLon = mntSt.Longitude * R2D;
      renderTonightTargets(state.userLat, state.userLon, '');
    }

    // Focuser
    setVal('tsFocusPos', foc.Position);
    setVal('tsFocusMin', focLim.Min);
    setVal('tsFocusMax', focLim.Max);
    if ($('tsAutoFocusGoto'))  $('tsAutoFocusGoto').checked  = !!focAdv.AutoFocusAfterGotoIsEnabled;
    if ($('tsTempAutoFocus'))  $('tsTempAutoFocus').checked  = !!focAdv.TemperatureShiftAutoFocusIsEnabled;
    setVal('tsTempThreshold', focAdv.ThresholdTemperatureC !== undefined ? `${focAdv.ThresholdTemperatureC}°C` : '—');

    // Environment
    setVal('tsAmbientTemp', env.AmbientTemperature !== undefined ? `${env.AmbientTemperature?.toFixed(1)}°C` : '—');
    setVal('tsCameraTemp',  env.CameraTemperature  !== undefined ? `${env.CameraTemperature?.toFixed(1)}°C`  : '—');
    setVal('tsCpuTemp',     env.CpuTemperature     !== undefined ? `${env.CpuTemperature?.toFixed(1)}°C`     : '—');
    setVal('tsHumidity',    env.Humidity           !== undefined ? `${env.Humidity?.toFixed(0)}%`            : '—');
    setVal('tsDewMode',      dew.Mode);
    setVal('tsDewLevel',     dew.HeaterLevel !== undefined ? `${(dew.HeaterLevel * 100).toFixed(0)}%` : '—');
    setVal('tsDewAggression', dew.Aggression);

    // Network
    setVal('tsNetIp', state.ip);
    const hasInternet = inet.Value;
    setVal('tsInternet', hasInternet ? '✓ Connected' : '✗ No connection', hasInternet ? 'good' : 'warn');
    if ($('tsForceDirectConnect')) $('tsForceDirectConnect').checked = !!net.Value;

    // LED
    if ($('tsLedBrightness')) $('tsLedBrightness').value = led.BrightnessLevel ?? 1;

    // Enable buttons
    $('btnRefreshTelescopeSettings').disabled = false;
    $('btnCheckUpdate').disabled = false;
    $('btnSaveFocuserSettings').disabled = false;
    $('btnSaveNetworkSettings').disabled = false;
  });
}

// Load when tab is clicked


$('btnRefreshTelescopeSettings').addEventListener('click', () => loadTelescopeSettings());

$('btnCheckUpdate').addEventListener('click', async () => {
  if (!state.connected) return;
  toast('Checking for firmware updates…', 'info');
  const r = await api.setSetting({ ip: state.ip, command: 'HasUpdateAvailable', destination: 'System', params: { ForceCheck: true } });
  if (r.success) {
    const avail = r.result?.IsAvailableOnline;
    if (avail) toast('✓ Firmware update available!', 'success');
    else toast('Firmware is up to date', 'info');
    const el = $('tsUpdateAvail');
    if (el) { el.textContent = avail ? '✓ Available' : 'Up to date'; el.className = `tele-val ${avail ? 'warn' : 'good'}`; }
  }
});

$('btnSaveFocuserSettings').addEventListener('click', async () => {
  if (!state.connected) return;
  await api.setSetting({
    ip: state.ip, command: 'SetFocuserAdvancedSettings', destination: 'Focuser',
    params: {
      AutoFocusAfterGotoIsEnabled:          $('tsAutoFocusGoto').checked,
      TemperatureShiftAutoFocusIsEnabled:   $('tsTempAutoFocus').checked,
    }
  });
  toast('✓ Focuser settings saved', 'success');
});

$('btnSaveNetworkSettings').addEventListener('click', async () => {
  if (!state.connected) return;
  await api.setSetting({
    ip: state.ip, command: 'SetForceDirectConnect', destination: 'Network',
    params: { Value: $('tsForceDirectConnect').checked }
  });
  await api.setSetting({
    ip: state.ip, command: 'SetBrightnessLevel', destination: 'LedRing',
    params: { BrightnessLevel: parseFloat($('tsLedBrightness').value) }
  });
  toast('✓ Network/LED settings saved', 'success');
});

// ── About Tab ──────────────────────────────────────────────────────────────
(function initAbout() {
  // Populate system info when tab is opened
  document.querySelectorAll('.nav-tab').forEach(tab => {
    if (tab.dataset.tab !== 'about') return;
    tab.addEventListener('click', () => {
      const ev = $('aboutElectron');
      const nv = $('aboutNode');
      const pv = $('aboutPlatform');
      if (ev) ev.textContent = process?.versions?.electron || '—';
      if (nv) nv.textContent = process?.versions?.node     || '—';
      if (pv) pv.textContent = `Windows ${process?.getSystemVersion?.() || ''}`.trim();
      api.checkFFmpeg().then(r => {
        const fv = $('aboutFFmpeg');
        if (fv) fv.textContent = r.ok ? (r.version?.split(' ')[0] || 'Ready') : 'Not found';
      });
    });
  });

  // Ko-fi donate — open Ko-fi page
  $('btnKofi').addEventListener('click', () => {
    api.openExternal('https://ko-fi.com/guinnessstache');
  });

  // Open the PDF manual from the install directory
  $('btnOpenManual').addEventListener('click', () => {
    api.revealFile('CelestronOriginControl_Manual.pdf');
  });

  $('btnOpenCelestron').addEventListener('click', () => {
    api.openExternal('https://www.celestron.com/products/origin-intelligent-home-observatory');
  });

  $('btnOpenSomaFM').addEventListener('click', () => {
    api.openExternal('https://somafm.com');
  });

  $('btnOpenOpenMeteo').addEventListener('click', () => {
    api.openExternal('https://open-meteo.com');
  });
})();

// ── Settings ───────────────────────────────────────────────────────────────

$('gcpLink').addEventListener('click', e => { e.preventDefault(); api.openExternal('https://studio.youtube.com/'); });

// Location settings
$('btnSaveLocation').addEventListener('click', async () => {
  const lat  = parseFloat($('locationLat').value);
  const lon  = parseFloat($('locationLon').value);
  const city = $('locationCity').value.trim();
  if (isNaN(lat) || isNaN(lon)) { toast('Enter valid latitude and longitude', 'error'); return; }
  const loc = { lat, lon, city };
  await api.saveLocation(loc);
  state.userLat      = lat;
  state.userLon      = lon;
  state.locationName = city;
  $('locationStatus').textContent = `✓ Saved — ${lat.toFixed(4)}, ${lon.toFixed(4)}`;
  toast('✓ Location saved', 'success');
  renderTonightTargets(lat, lon, city);
});

$('btnAutoDetectLocation').addEventListener('click', async () => {
  $('locationStatus').textContent = 'Initialize your telescope with the Celestron app to auto-detect location…';
  toast('Connect & initialize telescope in the Celestron app to auto-set location', 'info');
});

// Pre-fill location fields if saved
api.getLocation().then(loc => {
  if (loc) {
    if ($('locationLat')) $('locationLat').value  = loc.lat;
    if ($('locationLon')) $('locationLon').value  = loc.lon;
    if ($('locationCity')) $('locationCity').value = loc.city || '';
    $('locationStatus').textContent = `${loc.city ? loc.city + ' · ' : ''}${loc.lat?.toFixed(2)}°, ${loc.lon?.toFixed(2)}°`;
  }
});

$('btnInstallFfmpeg').addEventListener('click', () => { api.openExternal('https://ffmpeg.org/download.html'); });



// ══════════════════════════════════════════════════════════════════════════════
// ── Sky Chart ─────────────────────────────────────────────────────────────────
// ══════════════════════════════════════════════════════════════════════════════

// ── Astronomical math ─────────────────────────────────────────────────────────
function skyJD(d) { return d.getTime() / 86400000 + 2440587.5; }

function skyLST(jd, lonDeg) {
  const T = (jd - 2451545.0) / 36525;
  let g = 280.46061837 + 360.98564736629*(jd-2451545) + T*T*0.000387933 - T*T*T/38710000;
  return ((g + lonDeg) % 360 + 360) % 360;
}

function raDecToAltAz(raDeg, decDeg, latDeg, lstDeg) {
  const H  = ((lstDeg - raDeg) % 360 + 360) % 360;
  const Hr = H  * Math.PI / 180;
  const dr = decDeg * Math.PI / 180;
  const Lr = latDeg * Math.PI / 180;
  const sinAlt = Math.sin(dr)*Math.sin(Lr) + Math.cos(dr)*Math.cos(Lr)*Math.cos(Hr);
  const alt = Math.asin(Math.max(-1, Math.min(1, sinAlt))) * 180 / Math.PI;
  const cosAlt = Math.cos(alt * Math.PI / 180);
  const cosAz = cosAlt > 0.001
    ? (Math.sin(dr) - sinAlt*Math.sin(Lr)) / (cosAlt*Math.cos(Lr))
    : 0;
  let az = Math.acos(Math.max(-1, Math.min(1, cosAz))) * 180 / Math.PI;
  if (Math.sin(Hr) > 0) az = 360 - az;
  return { alt, az };
}

// ── Catalog ───────────────────────────────────────────────────────────────────
const SKY_OBJECTS = [
  {ra:83.82,  dec:5.39,   mag:0.5,  name:'Betelgeuse',        type:'star'},
  {ra:88.79,  dec:7.41,   mag:0.1,  name:'Rigel',             type:'star'},
  {ra:101.29, dec:-16.72, mag:-1.4, name:'Sirius',            type:'star'},
  {ra:95.99,  dec:22.51,  mag:0.1,  name:'Pollux',            type:'star'},
  {ra:113.65, dec:31.89,  mag:0.4,  name:'Castor',            type:'star'},
  {ra:79.17,  dec:45.99,  mag:0.1,  name:'Capella',           type:'star'},
  {ra:68.98,  dec:16.51,  mag:0.9,  name:'Aldebaran',         type:'star'},
  {ra:116.33, dec:-28.97, mag:-0.7, name:'Canopus',           type:'star'},
  {ra:297.69, dec:8.87,   mag:0.8,  name:'Altair',            type:'star'},
  {ra:279.23, dec:38.78,  mag:0.0,  name:'Vega',              type:'star'},
  {ra:310.36, dec:45.28,  mag:1.3,  name:'Deneb',             type:'star'},
  {ra:114.83, dec:5.23,   mag:0.3,  name:'Procyon',           type:'star'},
  {ra:201.30, dec:-11.16, mag:1.0,  name:'Spica',             type:'star'},
  {ra:213.22, dec:19.18,  mag:0.0,  name:'Arcturus',          type:'star'},
  {ra:152.09, dec:11.97,  mag:1.4,  name:'Regulus',           type:'star'},
  {ra:247.35, dec:-26.43, mag:0.9,  name:'Antares',           type:'star'},
  {ra:219.92, dec:-60.84, mag:0.0,  name:'Alpha Centauri',    type:'star'},
  {ra:24.43,  dec:57.15,  mag:2.1,  name:'Mirfak',            type:'star'},
  {ra:45.57,  dec:4.09,   mag:2.0,  name:'Menkar',            type:'star'},
  {ra:83.82,  dec:-5.39,  mag:6.0,  name:'M42 Orion Nebula',  type:'nebula',  desc:'Great Orion Nebula, stellar nursery'},
  {ra:84.05,  dec:22.01,  mag:5.7,  name:'M1 Crab Nebula',    type:'nebula',  desc:'Supernova remnant in Taurus'},
  {ra:270.89, dec:-24.38, mag:4.6,  name:'M8 Lagoon Nebula',  type:'nebula',  desc:'Emission nebula in Sagittarius'},
  {ra:274.70, dec:-16.18, mag:6.3,  name:'M16 Eagle Nebula',  type:'nebula',  desc:'Home of the Pillars of Creation'},
  {ra:275.92, dec:-18.52, mag:6.0,  name:'M17 Omega Nebula',  type:'nebula',  desc:'Emission nebula in Sagittarius'},
  {ra:148.97, dec:69.68,  mag:8.0,  name:"M81 Bode's Galaxy", type:'galaxy',  desc:'Spiral galaxy in Ursa Major'},
  {ra:148.89, dec:69.06,  mag:8.4,  name:'M82 Cigar Galaxy',  type:'galaxy',  desc:'Starburst galaxy near M81'},
  {ra:202.47, dec:47.20,  mag:8.7,  name:'M51 Whirlpool',     type:'galaxy',  desc:'Face-on spiral with companion'},
  {ra:13.16,  dec:41.27,  mag:3.5,  name:'M31 Andromeda',     type:'galaxy',  desc:'Nearest large galaxy, 2.5M ly'},
  {ra:24.17,  dec:42.35,  mag:6.3,  name:'M33 Triangulum',    type:'galaxy',  desc:'Third largest in Local Group'},
  {ra:205.54, dec:28.38,  mag:8.0,  name:'M64 Black Eye',     type:'galaxy',  desc:'Black Eye Galaxy'},
  {ra:23.46,  dec:30.66,  mag:5.7,  name:'M45 Pleiades',      type:'cluster', desc:'Seven Sisters open cluster'},
  {ra:100.99, dec:24.11,  mag:5.6,  name:'M35',               type:'cluster', desc:'Open cluster in Gemini'},
  {ra:250.42, dec:36.46,  mag:5.8,  name:'M13 Hercules',      type:'cluster', desc:'Great Globular Cluster'},
  {ra:245.90, dec:26.10,  mag:6.5,  name:'M92',               type:'cluster', desc:'Globular cluster in Hercules'},
  {ra:283.40, dec:-12.53, mag:7.5,  name:'M11 Wild Duck',     type:'cluster', desc:'Rich open cluster in Scutum'},
  {ra:268.47, dec:-34.79, mag:4.2,  name:'M6 Butterfly',      type:'cluster', desc:'Butterfly Cluster in Scorpius'},
  {ra:269.27, dec:-34.80, mag:3.3,  name:'M7',                type:'cluster', desc:'Bright open cluster in Scorpius'},
  {ra:255.98, dec:-26.26, mag:5.1,  name:'M4',                type:'cluster', desc:'Nearest globular cluster'},
  {ra:314.70, dec:44.16,  mag:6.3,  name:'M15',               type:'cluster', desc:'Dense globular in Pegasus'},
  {ra:322.49, dec:12.17,  mag:6.3,  name:'M2',                type:'cluster', desc:'Globular cluster in Aquarius'},
  {ra:83.18,  dec:22.01,  mag:-2.0, name:'Jupiter',  type:'planet', desc:'Largest planet',             _planet:true},
  {ra:130.24, dec:21.15,  mag:1.2,  name:'Saturn',   type:'planet', desc:'Ringed planet',              _planet:true},
  {ra:52.55,  dec:18.36,  mag:-4.0, name:'Venus',    type:'planet', desc:'Brightest planet',           _planet:true},
  {ra:300.19, dec:-21.79, mag:0.5,  name:'Mars',     type:'planet', desc:'Red planet',                 _planet:true},
];

// ── View state ────────────────────────────────────────────────────────────────
// The view is defined by two numbers:
//   skyAzCentre  = azimuth (degrees) at horizontal centre of canvas
//   skyAltCentre = altitude (degrees) at vertical centre of canvas
// Dragging left/right changes skyAzCentre
// Dragging up/down changes skyAltCentre
let skyAzCentre  = 180;   // start looking South
let skyAltCentre = 30;    // start with centre at 30° altitude
let skyHover     = null;
let skySelected  = null;
let skyFilter    = '';
let skyComputedObjs = [];

// Drag tracking
let skyPointerDown   = false;
let skyDragging      = false;
let skyDragStartX    = 0;
let skyDragStartY    = 0;
let skyDragStartAz   = 0;
let skyDragStartAlt  = 0;

// Degrees of sky visible per pixel (set once in drawSkyChart)
let skyDegPerPxH = 0;
let skyDegPerPxV = 0;
let skyZoom = 1.0; // 1 = default, <1 = zoomed in, >1 = zoomed out

const SKY_STYLE = {
  star:    {color:'#ffd700', glow:'rgba(255,215,0,.3)'},
  nebula:  {color:'#4fc3f7', glow:'rgba(79,195,247,.25)'},
  galaxy:  {color:'#ce93d8', glow:'rgba(206,147,216,.25)'},
  cluster: {color:'#80cbc4', glow:'rgba(128,203,196,.25)'},
  planet:  {color:'#ff8a65', glow:'rgba(255,138,101,.35)'},
};

function skyObjSize(obj) {
  if (obj.type === 'planet') return 5.5;
  if (obj.type === 'star')   return Math.max(1.5, 5 - obj.mag * 0.5);
  return 5;
}

// ── The one projection function — everything uses this ────────────────────────
function skyProject(az, alt, W, H) {
  // Horizontal: az relative to centre, each pixel = skyDegPerPxH degrees
  let dAz = az - skyAzCentre;
  // Wrap to -180..+180
  dAz = ((dAz + 180 + 720) % 360) - 180;
  const x = W / 2 + dAz / skyDegPerPxH;
  // Vertical: alt relative to centre, each pixel = skyDegPerPxV degrees
  // Higher alt = lower y (up on screen)
  const y = H / 2 - (alt - skyAltCentre) / skyDegPerPxV;
  return { x, y };
}

// ── Draw ──────────────────────────────────────────────────────────────────────
function drawSkyChart() {
  const canvas = $('skyCanvas');
  if (!canvas) return;

  const wrap = $('skyChartWrap');
  const W = wrap ? wrap.clientWidth : 600;
  const H = Math.round(W * 0.48);
  canvas.width  = W;
  canvas.height = H;

  // Set scale: show 180° horizontally and ~90° vertically, modified by zoom
  // skyZoom=1 → 180° wide, skyZoom=0.5 → 90° wide (zoomed in), skyZoom=2 → 360° (zoomed out)
  skyDegPerPxH = (180 * skyZoom) / W;
  skyDegPerPxV = (80  * skyZoom) / H;

  const ctx = canvas.getContext('2d');

  // Background
  const bg = ctx.createLinearGradient(0, 0, 0, H);
  bg.addColorStop(0, '#04070f');
  bg.addColorStop(1, '#080e1a');
  ctx.fillStyle = bg;
  ctx.fillRect(0, 0, W, H);

  const lat = (typeof skyLat !== 'undefined' && skyLat) ? skyLat : (state.userLat ?? 42.36);
  const lon = (typeof skyLon !== 'undefined' && skyLon) ? skyLon : (state.userLon ?? -71.06);
  const jd  = skyJD(new Date());
  const LST = skyLST(jd, lon);

  // ── Grid lines ──────────────────────────────────────────────────────────────
  // Horizontal: altitude lines every 15°
  for (let a = -15; a <= 90; a += 15) {
    const {y} = skyProject(skyAzCentre, a, W, H);
    if (y < -5 || y > H + 5) continue;
    const isHorizon = a === 0;
    ctx.strokeStyle = isHorizon ? 'rgba(79,195,247,.4)' : 'rgba(79,195,247,.08)';
    ctx.lineWidth   = isHorizon ? 1.5 : 1;
    ctx.setLineDash(isHorizon ? [] : [3, 5]);
    ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(W, y); ctx.stroke();
    ctx.setLineDash([]);
    if (a >= 0) {
      ctx.fillStyle = 'rgba(79,195,247,.4)';
      ctx.font = '9px monospace';
      ctx.fillText(`${a}°`, 3, y - 2);
    }
  }

  // Vertical: azimuth lines every 45°
  const cardinals = {0:'N', 45:'NE', 90:'E', 135:'SE', 180:'S', 225:'SW', 270:'W', 315:'NW'};
  for (let az = 0; az < 360; az += 45) {
    const {x} = skyProject(az, skyAltCentre, W, H);
    if (x < -20 || x > W + 20) continue;
    const label = cardinals[az];
    const major = az % 90 === 0;
    ctx.strokeStyle = major ? 'rgba(79,195,247,.15)' : 'rgba(79,195,247,.06)';
    ctx.lineWidth = 1;
    ctx.setLineDash([3, 5]);
    ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, H); ctx.stroke();
    ctx.setLineDash([]);
    ctx.fillStyle = major ? 'rgba(79,195,247,.75)' : 'rgba(79,195,247,.4)';
    ctx.font = `${major ? 12 : 10}px monospace`;
    ctx.textAlign = 'center';
    ctx.fillText(label, x, H - 5);
  }
  ctx.textAlign = 'left';

  // ── Horizon shade (below horizon) ──────────────────────────────────────────
  const {y: hY} = skyProject(skyAzCentre, 0, W, H);
  if (hY < H) {
    ctx.fillStyle = 'rgba(0,0,0,.4)';
    ctx.fillRect(0, hY, W, H - hY);
  }

  // ── Objects ─────────────────────────────────────────────────────────────────
  skyComputedObjs = [];
  const filt = skyFilter.toLowerCase();

  SKY_OBJECTS.forEach(obj => {
    const {alt, az} = raDecToAltAz(obj.ra, obj.dec, lat, LST);

    if (filt && !obj.name.toLowerCase().includes(filt) && !obj.type.includes(filt)) return;

    const {x, y} = skyProject(az, alt, W, H);
    if (x < -30 || x > W + 30 || y < -30 || y > H + 30) return;

    const style  = SKY_STYLE[obj.type] || SKY_STYLE.star;
    const size   = skyObjSize(obj);
    const above  = alt >= 0;
    const isHov  = skyHover?.name === obj.name;
    const isSel  = skySelected?.name === obj.name;
    const alpha  = above ? 1 : 0.25;

    ctx.globalAlpha = alpha;

    // Selection rings
    if (isSel) {
      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2;
      ctx.setLineDash([]);
      ctx.beginPath(); ctx.arc(x, y, size + 7, 0, Math.PI * 2); ctx.stroke();
      ctx.strokeStyle = 'rgba(79,195,247,.5)';
      ctx.lineWidth = 1;
      ctx.beginPath(); ctx.arc(x, y, size + 11, 0, Math.PI * 2); ctx.stroke();
    }

    if (isHov && !isSel) {
      ctx.strokeStyle = 'rgba(255,255,255,.45)';
      ctx.lineWidth = 1.5;
      ctx.setLineDash([]);
      ctx.beginPath(); ctx.arc(x, y, size + 5, 0, Math.PI * 2); ctx.stroke();
    }

    if (obj.type === 'star' || obj.type === 'planet') {
      const g = ctx.createRadialGradient(x, y, 0, x, y, size * 3);
      g.addColorStop(0, style.glow); g.addColorStop(1, 'transparent');
      ctx.fillStyle = g; ctx.beginPath(); ctx.arc(x, y, size * 3, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = isSel || isHov ? '#ffffff' : style.color;
      ctx.beginPath(); ctx.arc(x, y, size, 0, Math.PI * 2); ctx.fill();
    } else {
      ctx.strokeStyle = isSel || isHov ? '#ffffff' : style.color;
      ctx.lineWidth = isSel ? 2 : 1.5;
      ctx.setLineDash([]);
      ctx.beginPath(); ctx.arc(x, y, size, 0, Math.PI * 2); ctx.stroke();
      ctx.fillStyle = style.glow; ctx.fill();
    }

    ctx.globalAlpha = 1;

    const showLbl = isSel || isHov || obj.type !== 'star' || obj.mag < 1.5;
    if (showLbl) {
      ctx.font = `${isSel || isHov ? 'bold ' : ''}10px sans-serif`;
      ctx.fillStyle = isSel ? '#ffffff' : isHov ? 'rgba(255,255,255,.9)' : 'rgba(232,237,245,.6)';
      ctx.fillText(obj.name, x + size + 4, y + 4);
    }

    skyComputedObjs.push({...obj, alt, az, x, y, above});
  });

  // ── Info bar ──────────────────────────────────────────────────────────────
  const bar = $('skyCompassBar');
  if (bar) {
    const az0 = ((skyAzCentre + 720) % 360).toFixed(0);
    const zoomPct = Math.round(100 / skyZoom);
    bar.innerHTML =
      `<span style="position:absolute;left:0">Drag ← → rotate · ↑ ↓ tilt · scroll zoom</span>` +
      `<span style="position:absolute;left:50%;transform:translateX(-50%)">` +
        `Az ${az0}° · Alt ${skyAltCentre.toFixed(0)}° · ${zoomPct}° view` +
      `</span>` +
      `<span style="position:absolute;right:0;cursor:pointer;color:rgba(79,195,247,.6)" ` +
        `onclick="skyZoom=1;skyAzCentre=180;skyAltCentre=30;drawSkyChart()" ` +
        `title="Reset view">↺ reset</span>`;
  }

  const locEl = $('skyLocationLabel');
  if (locEl) locEl.textContent = `${lat.toFixed(2)}°N ${Math.abs(lon).toFixed(2)}°${lon < 0 ? 'W' : 'E'}`;

  updateSkyList(skyComputedObjs);
}

// ── Object list ────────────────────────────────────────────────────────────────
function updateSkyList(objs) {
  const listEl  = $('skyObjectList');
  const titleEl = $('skyListTitle');
  if (!listEl) return;
  const filt  = skyFilter.toLowerCase();
  const items = objs.filter(o => o.above).sort((a, b) => b.alt - a.alt);
  if (titleEl) titleEl.textContent = filt ? `RESULTS: "${skyFilter.toUpperCase()}"` : 'VISIBLE OBJECTS NOW';
  listEl.innerHTML = '';
  if (!items.length) {
    listEl.innerHTML = '<div style="font-size:12px;color:var(--text-dim);padding:6px 0">No objects above horizon</div>';
    return;
  }
  items.slice(0, 50).forEach(obj => {
    const style = SKY_STYLE[obj.type] || SKY_STYLE.star;
    const isSel = skySelected?.name === obj.name;
    const row = document.createElement('div');
    row.style.cssText = `display:flex;align-items:center;gap:8px;padding:4px 8px;border-radius:5px;
      cursor:pointer;font-size:12px;border:1px solid ${isSel ? 'rgba(79,195,247,.3)' : 'transparent'};
      background:${isSel ? 'rgba(79,195,247,.08)' : 'rgba(79,195,247,.02)'};transition:all .12s`;
    row.innerHTML = `
      <span style="width:7px;height:7px;border-radius:50%;background:${style.color};flex-shrink:0"></span>
      <span style="flex:1;color:var(--text)">${obj.name}</span>
      <span style="color:var(--text-dim);font-size:11px;font-family:var(--ui)">${obj.alt.toFixed(0)}° alt</span>
      <span style="color:var(--text-dim);font-size:10px;font-family:var(--ui);text-transform:capitalize;min-width:42px">${obj.type}</span>`;
    row.addEventListener('mouseenter', () => { skyHover = obj; drawSkyChart(); });
    row.addEventListener('mouseleave', () => { skyHover = null; drawSkyChart(); });
    row.addEventListener('click', () => selectSkyObject(obj));
    listEl.appendChild(row);
  });
}

// ── Select object ─────────────────────────────────────────────────────────────
function selectSkyObject(obj) {
  skySelected = (obj && skySelected?.name === obj.name) ? null : obj;
  const card = $('skyInfoCard');
  if (!skySelected || !card) {
    if (card) card.style.display = 'none';
    drawSkyChart(); updateSkyList(skyComputedObjs);
    return;
  }
  // Pan to show selected object
  skyAzCentre  = ((skySelected.az + 720) % 360);
  skyAltCentre = Math.max(10, Math.min(70, skySelected.alt));

  $('skyInfoName').textContent = skySelected.name;
  $('skyInfoAlt').textContent  = `${skySelected.alt.toFixed(1)}°`;
  $('skyInfoAz').textContent   = `${skySelected.az.toFixed(1)}°`;
  $('skyInfoType').textContent = skySelected.type + (skySelected._planet ? ' *' : '');
  card.style.display = 'block';

  const gotoBtn = $('skyInfoGoto');
  if (gotoBtn) {
    gotoBtn.disabled = !state.connected;
    gotoBtn.title    = state.connected ? '' : 'Connect telescope first';
  }
  drawSkyChart(); updateSkyList(skyComputedObjs);
}

// ── Info card ─────────────────────────────────────────────────────────────────
$('skyInfoClose') && $('skyInfoClose').addEventListener('click', () => {
  skySelected = null;
  $('skyInfoCard').style.display = 'none';
  drawSkyChart(); updateSkyList(skyComputedObjs);
});

$('skyInfoGoto') && $('skyInfoGoto').addEventListener('click', () => {
  if (!skySelected || !state.connected) return;
  const obj = skySelected;
  state.gotoTarget = obj.name;
  if ($('stackTarget')) $('stackTarget').textContent = obj.name;
  api.command({ ip: state.ip, command: 'slewtocoordinates',
    params: { RightAscension: obj.ra / 15, Declination: obj.dec } });
  toast(`Slewing to ${obj.name}…`, 'info');
  document.querySelector('[data-tab="view"]')?.click();
});

$('skyInfoNight') && $('skyInfoNight').addEventListener('click', () => {
  if (!skySelected) return;
  toast(`${skySelected.name} noted for tonight`, 'info');
});

// ── Canvas interaction (drag to pan, click to select) ────────────────────────
function initSkyChart() {
  const canvas = $('skyCanvas');
  if (!canvas || canvas._skyInited) return;
  canvas._skyInited = true;
  const wrap = $('skyChartWrap');

  const onStart = (cx, cy) => {
    skyPointerDown  = true;
    skyDragging     = false;
    skyDragStartX   = cx;
    skyDragStartY   = cy;
    skyDragStartAz  = skyAzCentre;
    skyDragStartAlt = skyAltCentre;
    if (wrap) wrap.style.cursor = 'grabbing';
  };

  const onMove = (cx, cy) => {
    if (!skyPointerDown) return;
    const dx = cx - skyDragStartX;
    const dy = cy - skyDragStartY;
    if (Math.abs(dx) > 3 || Math.abs(dy) > 3) skyDragging = true;
    if (!skyDragging) return;
    // Use the scale that was set at last draw
    const dpxH = skyDegPerPxH || 180 / (canvas.width  || 600);
    const dpxV = skyDegPerPxV || 80  / (canvas.height || 288);
    // Drag left → az increases (look further right)
    skyAzCentre  = ((skyDragStartAz  - dx * dpxH) + 720) % 360;
    // Drag up (dy negative) → alt increases (look higher)
    skyAltCentre = Math.max(-10, Math.min(80, skyDragStartAlt - dy * dpxV));
    drawSkyChart();
  };

  const onEnd = (cx, cy) => {
    if (wrap) wrap.style.cursor = 'grab';
    if (!skyDragging) {
      // Click — hit test against computed objects
      const rect  = canvas.getBoundingClientRect();
      const mx = cx * (canvas.width  / rect.width)  - rect.left * (canvas.width  / rect.width);
      const my = cy * (canvas.height / rect.height) - rect.top  * (canvas.height / rect.height);
      // Recalculate using page coords properly
      const px = (cx - rect.left) * (canvas.width  / rect.width);
      const py = (cy - rect.top)  * (canvas.height / rect.height);
      let nearest = null, bestD = 18;
      skyComputedObjs.forEach(obj => {
        const d = Math.hypot(obj.x - px, obj.y - py);
        if (d < bestD) { bestD = d; nearest = obj; }
      });
      selectSkyObject(nearest);
    }
    skyPointerDown = false;
    skyDragging    = false;
  };

  // Mouse events
  canvas.addEventListener('mousedown', e => { e.preventDefault(); onStart(e.clientX, e.clientY); });
  window.addEventListener('mousemove', e => { if (skyPointerDown) onMove(e.clientX, e.clientY); });
  window.addEventListener('mouseup',   e => { if (skyPointerDown) onEnd(e.clientX, e.clientY); });

  // Touch events
  canvas.addEventListener('touchstart', e => { e.preventDefault(); onStart(e.touches[0].clientX, e.touches[0].clientY); }, {passive:false});
  canvas.addEventListener('touchmove',  e => { e.preventDefault(); onMove(e.touches[0].clientX, e.touches[0].clientY); },  {passive:false});
  canvas.addEventListener('touchend',   e => { e.preventDefault(); onEnd(e.changedTouches[0].clientX, e.changedTouches[0].clientY); }, {passive:false});

  // Hover (no drag)
  canvas.addEventListener('mousemove', e => {
    if (skyPointerDown) return;
    const rect = canvas.getBoundingClientRect();
    const px = (e.clientX - rect.left) * (canvas.width  / rect.width);
    const py = (e.clientY - rect.top)  * (canvas.height / rect.height);
    let nearest = null, bestD = 16;
    skyComputedObjs.forEach(obj => {
      const d = Math.hypot(obj.x - px, obj.y - py);
      if (d < bestD) { bestD = d; nearest = obj; }
    });
    if (nearest?.name !== skyHover?.name) { skyHover = nearest; drawSkyChart(); }
  });
  canvas.addEventListener('mouseleave', () => { skyHover = null; drawSkyChart(); });

  // Mouse wheel to zoom in/out
  canvas.addEventListener('wheel', e => {
    e.preventDefault();
    const zoomFactor = e.deltaY > 0 ? 1.15 : 0.87; // scroll down = zoom out, up = zoom in
    skyZoom = Math.max(0.1, Math.min(4.0, skyZoom * zoomFactor));
    drawSkyChart();
  }, { passive: false });
}

// ── Search & refresh ──────────────────────────────────────────────────────────
$('skySearch') && $('skySearch').addEventListener('input', () => {
  skyFilter = $('skySearch').value.trim();
  drawSkyChart();
});

$('btnSkyRefresh') && $('btnSkyRefresh').addEventListener('click', () => {
  drawSkyChart();
  toast('Sky chart refreshed', 'info');
});

// ── Activate on tab switch ────────────────────────────────────────────────────
document.querySelectorAll('[data-tab]').forEach(btn => {
  btn.addEventListener('click', () => {
    if (btn.dataset.tab === 'sky') {
      skyLat = state.userLat || null;
      skyLon = state.userLon || null;
      setTimeout(() => { initSkyChart(); drawSkyChart(); }, 80);
    }
  });
});

// Update location when telescope GPS arrives
let skyLat = null, skyLon = null;
api.onLocation && api.onLocation(loc => {
  if (loc?.lat) { skyLat = loc.lat; skyLon = loc.lon; }
});
