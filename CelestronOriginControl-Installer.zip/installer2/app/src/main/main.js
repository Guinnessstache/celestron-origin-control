const { app, BrowserWindow, ipcMain, shell, dialog } = require('electron');
const path = require('path');
const http = require('http');
const https = require('https');
const fs = require('fs');
const os = require('os');
const { exec, spawn } = require('child_process');
const net = require('net');
const { URL, URLSearchParams } = require('url');

let mainWindow;
let authWindow = null;
let ffmpegProcess = null;
let recordProcess = null;
let oauthCallbackServer = null;

let oauthTokens = null;

// ── Window ───────────────────────────────────────────────────────────────────
function createWindow() {
  const iconPath = path.join(__dirname, '../assets/telescope.ico');

  const winOpts = {
    width: 1440,
    height: 920,
    minWidth: 1100,
    minHeight: 700,
    backgroundColor: '#070a12',
    webPreferences: {
      nodeIntegration: false,
      contextIsolation: true,
      preload: path.join(__dirname, 'preload.js'),
      webSecurity: false,
    },
    // Start hidden - shown via ready-to-show or the 3s fallback below.
    // NOTE: titleBarStyle:'hidden' is intentionally omitted - it prevents
    // ready-to-show from firing on some Windows configurations.
    show: false,
  };

  // Only attach icon if the file actually exists
  if (fs.existsSync(iconPath)) {
    winOpts.icon = iconPath;
  }

  mainWindow = new BrowserWindow(winOpts);
  mainWindow.loadFile(path.join(__dirname, '../renderer/index.html'));

  // Primary show path
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
    mainWindow.focus();
  });

  // Fallback: force-show after 3 s if ready-to-show never fires
  const showTimer = setTimeout(() => {
    if (mainWindow && !mainWindow.isVisible()) {
      mainWindow.show();
      mainWindow.focus();
    }
  }, 3000);

  mainWindow.once('show', () => clearTimeout(showTimer));

  mainWindow.on('closed', () => {
    stopStreaming();
    stopRecording();
    stopOriginFrameReader();
    closeAuthServer();
    mainWindow = null;
  });
}

app.whenReady().then(() => {
  // Set Windows AppUserModelId so taskbar groups correctly and shows our icon
  if (process.platform === 'win32') {
    app.setAppUserModelId('com.celestron.origin.control');
  }
  loadSavedConfig();
  createWindow();
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});

// ── Persist Config ────────────────────────────────────────────────────────────
const tokenPath  = () => path.join(app.getPath('userData'), 'yt_tokens.json');
const configPath = () => path.join(app.getPath('userData'), 'oauth_config.json');

function loadSavedConfig() {
  try { if (fs.existsSync(tokenPath()))  oauthTokens = JSON.parse(fs.readFileSync(tokenPath(),  'utf8')); } catch(_){}
  try { if (fs.existsSync(configPath())) oauthConfig = { ...oauthConfig, ...JSON.parse(fs.readFileSync(configPath(), 'utf8')) }; } catch(_){}
}
function saveTokens(t)  { oauthTokens = t; fs.writeFileSync(tokenPath(),  JSON.stringify(t), 'utf8'); }
function saveOAuthCfg(c){ oauthConfig = { ...oauthConfig, ...c }; fs.writeFileSync(configPath(), JSON.stringify(oauthConfig), 'utf8'); }

// ── Telescope Discovery ───────────────────────────────────────────────────────
ipcMain.handle('telescope:discover', async () => {
  const ifaces  = os.networkInterfaces();
  const subnets = new Set();
  const candidates = ['192.168.68.1']; // Celestron Origin AP mode default

  for (const list of Object.values(ifaces)) {
    for (const iface of list) {
      if (iface.family === 'IPv4' && !iface.internal) {
        const parts = iface.address.split('.');
        const base  = `${parts[0]}.${parts[1]}.${parts[2]}`;
        subnets.add(base);
        candidates.push(`${base}.1`);
      }
    }
  }
  for (const subnet of subnets) {
    for (let i = 2; i <= 254; i++) candidates.push(`${subnet}.${i}`);
  }

  const unique  = [...new Set(candidates)];
  const results = [];
  const BATCH   = 40;
  let scanned   = 0;

  for (let i = 0; i < unique.length; i += BATCH) {
    const hits = await Promise.all(
      unique.slice(i, i + BATCH).map(async ip => {
        mainWindow?.webContents.send('telescope:scanProgress', { scanned: ++scanned, total: unique.length });
        const score = await scoreDevice(ip);
        return score > 0 ? { ip, score } : null;
      })
    );
    hits.filter(Boolean).forEach(h => results.push(h));
  }

  // Sort by score descending so most likely telescope is first
  results.sort((a, b) => b.score - a.score);
  return results.map(r => ({ ip: r.ip }));
});

// Score a device — higher = more likely to be a Celestron telescope.
// Returns 0 if definitely not a telescope.
async function scoreDevice(ip) {
  // First: quick TCP check on port 80
  const hasPort80 = await checkTcpPort(ip, 80);
  if (!hasPort80) return 0;

  // Fetch the root page and the ALPACA management endpoint in parallel
  const [rootResp, alpacaResp] = await Promise.all([
    httpGet(ip, '/'),
    httpGet(ip, '/api/v1/telescope/0/name'),
  ]);

  let score = 0;

  // Check ALPACA response — strongest signal
  if (alpacaResp.ok) {
    try {
      const j = JSON.parse(alpacaResp.body);
      if (typeof j.Value !== 'undefined') {
        // Valid ALPACA response — almost certainly a telescope
        score += 100;
        const name = (j.Value || '').toLowerCase();
        if (name.includes('celestron') || name.includes('origin')) score += 50;
      }
    } catch (_) {}
  }

  // Check root page for telescope/celestron mentions
  if (rootResp.ok) {
    const body = rootResp.body.toLowerCase();
    if (body.includes('celestron'))   score += 80;
    if (body.includes('origin'))      score += 40;
    if (body.includes('telescope'))   score += 40;
    if (body.includes('alpaca'))      score += 40;
    if (body.includes('ascom'))       score += 30;

    // Common non-telescope devices to exclude
    if (body.includes('router') || body.includes('gateway') ||
        body.includes('modem')  || body.includes('admin') ||
        body.includes('printer') || body.includes('synology') ||
        body.includes('qnap') || body.includes('ubiquiti') ||
        body.includes('unifi') || body.includes('netgear') ||
        body.includes('linksys') || body.includes('asus router') ||
        body.includes('tp-link')) {
      return 0; // Definitely not a telescope
    }
  }

  return score;
}

// Simple HTTP GET helper that returns { ok, body, status }
function httpGet(ip, path) {
  return new Promise(res => {
    const req = http.get({ hostname: ip, port: 80, path, timeout: 2000 }, r => {
      let d = '';
      r.on('data', c => { d += c; if (d.length > 4096) req.destroy(); }); // cap at 4KB
      r.on('end',  () => res({ ok: r.statusCode < 400, status: r.statusCode, body: d }));
    });
    req.on('error',   () => res({ ok: false, status: 0, body: '' }));
    req.on('timeout', () => { req.destroy(); res({ ok: false, status: 0, body: '' }); });
  });
}

ipcMain.handle('telescope:connect',   async (_, ip)      => { try { return { success:true, info: await getTelescopeInfo(ip) }; } catch(e){ return { success:false, error:e.message }; } });
ipcMain.handle('telescope:command',   async (_, payload)  => { try { return { success:true, result: await sendTelescopeCommand(payload.ip, payload.command, payload.params) }; } catch(e){ return { success:false, error:e.message }; } });
ipcMain.handle('telescope:getStatus', async (_, ip)      => { try { return { success:true, status: await getTelescopeStatus(ip) }; } catch(e){ return { success:false, error:e.message }; } });

ipcMain.handle('telescope:getAllSettings', async (_, ip) => {
  try {
    const results = await fetchAllTelescopeSettings(ip);
    return { success: true, data: results };
  } catch(e) { return { success: false, error: e.message }; }
});

ipcMain.handle('telescope:setSetting', async (_, { ip, command, destination, params }) => {
  try {
    const result = await sendSmartScopeCommand(ip, destination, { Command: command, ...params });
    return { success: true, result };
  } catch(e) { return { success: false, error: e.message }; }
});

// Port scanner — finds all open TCP ports on the telescope
ipcMain.handle('telescope:scanPorts', async (_, ip) => {
  const commonPorts = [
    80, 443, 554, 1883, 4040, 4567, 5000, 5555, 7624,
    8000, 8001, 8080, 8081, 8082, 8083, 8085, 8086,
    8088, 8089, 8090, 8443, 8554, 8765, 8888, 8899,
    9000, 9001, 9090, 9999, 10001, 12345,
  ];
  const open = [];
  await Promise.all(commonPorts.map(port =>
    checkTcpPort(ip, port).then(ok => { if (ok) open.push(port); })
  ));
  return open.sort((a,b) => a-b);
});

// Find which stream endpoint the telescope actually serves
ipcMain.handle('telescope:findStream', async (_, ip) => {
  // Celestron Origin protocol (confirmed via packet capture):
  // 1. WebSocket at ws://<ip>/SmartScope-1.0/mountControlEndpoint
  //    - Telescope sends "NewImageReady" JSON notifications with FileLocation
  // 2. App fetches each frame: http://<ip>/SmartScope-1.0/dev2/<FileLocation>
  //    e.g. http://<ip>/SmartScope-1.0/dev2/Images/Temp/8.jpg
  // Frames cycle 0-9, ~1fps, ~578KB each JPEG at 3056x2048

  // Verify the WebSocket endpoint responds
  const wsUrl = `ws://${ip}/SmartScope-1.0/mountControlEndpoint`;
  mainWindow?.webContents.send('telescope:debug', `Trying Origin WebSocket: ${wsUrl}`);

  const result = await probeWebSocketWithProtocol(wsUrl, undefined);
  if (result.connected || result.response.includes('101') || result.response.includes('connected')) {
    mainWindow?.webContents.send('telescope:debug', `Origin WebSocket connected: ${result.response}`);
    return {
      success: true,
      url: wsUrl,
      baseUrl: `http://${ip}/SmartScope-1.0/dev2/`,
      type: 'origin',
    };
  }

  // Fallback: try fetching a known frame path directly
  for (let i = 0; i <= 9; i++) {
    const testPath = `/SmartScope-1.0/dev2/Images/Temp/${i}.jpg`;
    const r = await httpGetFull(ip, 80, testPath);
    if (r.status === 200 && r.contentType.toLowerCase().includes('jpeg')) {
      mainWindow?.webContents.send('telescope:debug', `Direct JPEG found: ${testPath}`);
      return {
        success: true,
        url: `ws://${ip}/SmartScope-1.0/mountControlEndpoint`,
        baseUrl: `http://${ip}/SmartScope-1.0/dev2/`,
        type: 'origin',
        startFrame: i,
      };
    }
  }

  mainWindow?.webContents.send('telescope:debug', `Stream not found. Is telescope powered on?`);
  return { success: false, openPorts: [80] };
});

// Enhanced WebSocket probe — returns { connected, gotData, response }
function probeWebSocketWithProtocol(url, protocol) {
  return new Promise(res => {
    try {
      const opts = { handshakeTimeout: 2500 };
      if (protocol) opts.protocol = protocol;
      const ws = new (require('ws'))(url, opts);
      let gotData = false;
      let response = '';

      ws.on('open', () => {
        // Connected — send a minimal request in case the server needs one
        try { ws.send(JSON.stringify({ type: 'subscribe', channel: 'video' })); } catch(_){}
        try { ws.send(JSON.stringify({ cmd: 'stream', action: 'start' })); } catch(_){}
      });
      ws.on('message', data => {
        gotData = true;
        response = typeof data === 'string' ? data.slice(0, 100) : `[binary ${data.length || data.byteLength} bytes]`;
        ws.close();
        res({ connected: true, gotData: true, response });
      });
      ws.on('unexpected-response', (req, resp) => {
        // Server responded with non-101 — log the status
        res({ connected: false, gotData: false, response: `HTTP ${resp.statusCode}` });
      });
      ws.on('error', err => res({ connected: false, gotData: false, response: err.message }));
      ws.on('close', () => res({ connected: false, gotData, response }));

      setTimeout(() => {
        const wasConnected = ws.readyState === 1; // OPEN
        try { ws.close(); } catch(_){}
        res({ connected: wasConnected, gotData, response });
      }, 3000);
    } catch(e) { res({ connected: false, gotData: false, response: e.message }); }
  });
}

// Full HTTP GET that captures status, content-type, and body
function httpGetFull(ip, port, path) {
  return new Promise(res => {
    const req = http.get({ hostname: ip, port, path, timeout: 3000,
      headers: { 'User-Agent': 'CelestronOriginControl/2.0' }
    }, r => {
      const contentType = r.headers['content-type'] || '';
      let body = '';
      r.on('data', c => { body += c; if (body.length > 512) req.destroy(); });
      r.on('end',  () => res({ status: r.statusCode, contentType, body, headers: r.headers }));
    });
    req.on('error',   e => res({ status: 0, contentType: '', body: e.message, headers: {} }));
    req.on('timeout', () => { req.destroy(); res({ status: 0, contentType: '', body: 'timeout', headers: {} }); });
  });
}

// ── Celestron Origin Frame Reader ─────────────────────────────────────────────
// Protocol (confirmed via packet capture):
//   1. Connect WebSocket to ws://<ip>/SmartScope-1.0/mountControlEndpoint
//   2. Telescope sends JSON notifications including:
//      {"Command":"NewImageReady","FileLocation":"Images/Temp/8.jpg",...}
//   3. Fetch the JPEG: GET http://<ip>/SmartScope-1.0/dev2/Images/Temp/8.jpg
//   4. Send base64 frame to renderer via IPC

let originWs       = null;
let originBaseUrl  = '';
let originFetching = false;

function startOriginFrameReader(wsUrl, baseUrl, startFrame) {
  stopOriginFrameReader();
  originBaseUrl = baseUrl;

  mainWindow?.webContents.send('telescope:debug', `Connecting Origin WebSocket: ${wsUrl}`);

  const WS = require('ws');
  originWs = new WS(wsUrl, { handshakeTimeout: 5000 });

  originWs.on('open', () => {
    mainWindow?.webContents.send('telescope:debug', 'WebSocket connected — waiting for NewImageReady');
    // If we know a start frame, fetch it immediately
    if (startFrame !== undefined) {
      fetchAndSendFrame(`${baseUrl}Images/Temp/${startFrame}.jpg`);
    }
  });

  originWs.on('message', (data) => {
    try {
      const msg = JSON.parse(data.toString());
      if (msg.Command === 'NewImageReady' && msg.FileLocation) {
        const frameUrl = `${baseUrl}${msg.FileLocation}`;
        const imgType = msg.ImageType || 'LIVE';
        mainWindow?.webContents.send('telescope:debug', `NewImageReady: ${msg.FileLocation} [${imgType}]`);
        mainWindow?.webContents.send('telescope:imageType', imgType);
        mainWindow?.webContents.send('telescope:imageMeta', {
          imageType:    imgType,
          exposureTime: msg.ExposureTime || 0,
          ra:           msg.Ra,
          dec:          msg.Dec,
        });
        fetchAndSendFrame(frameUrl);
      }
      // Forward version info to renderer whenever we see it
      if (msg.Command === 'GetVersion' && (msg.Number || msg.Version)) {
        let v = msg.Number || msg.Version || '';
        if (v.includes(' ')) v = v.split(' ')[0];
        mainWindow?.webContents.send('telescope:version', v);
      }
      // Extract lat/lon from Mount GetStatus — broadcast every second, contains GPS in radians
      // Also fires from RunInitialize which has the same fields
      const hasLocation = msg.Latitude !== undefined && msg.Longitude !== undefined
                       && msg.Latitude !== 0 && msg.Longitude !== 0;
      if (hasLocation && (msg.Source === 'Mount' || msg.Command === 'RunInitialize')) {
        const R2D = 180 / Math.PI;
        const lat = msg.Latitude  * R2D;
        const lon = msg.Longitude * R2D;
        mainWindow?.webContents.send('telescope:location', { lat, lon, city: '' });
        // Save for future sessions (only write once — avoid hammering disk every second)
        if (!originWs._locationSaved) {
          originWs._locationSaved = true;
          try {
            const { app: electronApp } = require('electron');
            fs.writeFileSync(
              path.join(electronApp.getPath('userData'), 'location.json'),
              JSON.stringify({ lat, lon, city: '' }), 'utf8'
            );
          } catch(_) {}
        }
      }
      // Forward mount status for position display
      if (msg.Command === 'GetStatus' && msg.Source === 'Mount') {
        mainWindow?.webContents.send('telescope:mountStatus', msg);
      }
      // Forward TaskController status for initialization phase display
      if (msg.Command === 'GetStatus' && msg.Source === 'TaskController') {
        mainWindow?.webContents.send('telescope:taskStatus', msg);
        // Only broadcast debug for non-IDLE states to avoid log spam
        if (msg.State && msg.State !== 'IDLE') {
          mainWindow?.webContents.send('telescope:debug', `TaskCtrl: State=${msg.State} Stage=${msg.Stage}${msg.ErrorMessage ? ' Err='+msg.ErrorMessage : ''}`);
        }
      }
      // Also forward RunInitialize response so renderer knows command was received
      if (msg.Command === 'RunInitialize' && msg.Source === 'TaskController') {
        mainWindow?.webContents.send('telescope:taskStatus', { State: 'INITIALIZING', Stage: 'IN_PROGRESS', _isInitResponse: true });
        mainWindow?.webContents.send('telescope:debug', `RunInitialize response: ErrorCode=${msg.ErrorCode} Msg=${msg.ErrorMessage||'ok'}`);
      }
    } catch(_) {}
  });

  originWs.on('error', (err) => {
    mainWindow?.webContents.send('telescope:debug', `WS error: ${err.message}`);
    mainWindow?.webContents.send('stream:frameError', err.message);
  });

  originWs.on('close', () => {
    mainWindow?.webContents.send('telescope:debug', 'WebSocket closed');
  });
}

function fetchAndSendFrame(frameUrl) {
  if (originFetching) return; // don't pile up requests
  originFetching = true;

  const u = new URL(frameUrl);
  const req = http.get({
    hostname: u.hostname,
    port: parseInt(u.port) || 80,
    path: u.pathname,
    timeout: 5000,
    headers: { 'User-Agent': 'CelestronOriginControl/2.0' },
  }, (res) => {
    const chunks = [];
    res.on('data', c => chunks.push(c));
    res.on('end', () => {
      originFetching = false;
      const buf = Buffer.concat(chunks);
      if (buf.length > 100 && res.statusCode === 200) {
        mainWindow?.webContents.send('stream:frame', buf.toString('base64'));
      }
    });
    res.on('error', () => { originFetching = false; });
  });

  req.on('error', () => { originFetching = false; });
  req.on('timeout', () => { req.destroy(); originFetching = false; });
  req.end();
}

function stopOriginFrameReader() {
  if (originWs) {
    try { originWs.close(); } catch(_) {}
    originWs = null;
  }
  originFetching = false;
}

// Keep old mjpeg reader stubs
let mjpegReq = null;
function stopMjpegReader() { stopOriginFrameReader(); }

ipcMain.handle('telescope:requestVersion', async () => {
  if (!originWs || originWs.readyState !== 1) return { success: false };
  try {
    originWs.send(JSON.stringify({ Command:'GetVersion', Destination:'System', Source:'OriginMobileApp', SequenceID:99, Type:'Command' }));
    return { success: true };
  } catch(_) { return { success: false }; }
});

ipcMain.handle('stream:startFrames', async (_, streamUrl, baseUrl, startFrame) => {
  try {
    startOriginFrameReader(streamUrl, baseUrl || `http://${new URL(streamUrl).hostname}/SmartScope-1.0/dev2/`, startFrame);
    return { success: true };
  } catch(e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle('stream:stopFrames', async () => {
  stopOriginFrameReader();
  return { success: true };
});

// Keep old proxy stubs
ipcMain.handle('stream:startProxy', async (_, url) => { return { success: false }; });
ipcMain.handle('stream:stopProxy',  async ()      => { return { success: true };  });

ipcMain.handle('auth:setOAuthConfig', async (_, cfg) => { saveOAuthCfg(cfg); return { success: true }; });
ipcMain.handle('auth:getOAuthConfig', async ()       => ({ clientId: oauthConfig.clientId, hasSecret: !!oauthConfig.clientSecret }));

ipcMain.handle('auth:getStatus', async () => {
  if (!oauthTokens?.access_token) return { signedIn: false };
  if (Date.now() > (oauthTokens.expiry || 0) - 60000) {
    const ok = await refreshToken();
    if (!ok) return { signedIn: false };
  }
  return { signedIn: true, channelName: oauthTokens.channelName || 'YouTube Account' };
});

// ── Streaming ─────────────────────────────────────────────────────────────────
ipcMain.handle('stream:start', async (_, opts) => {
  try {
    await startYouTubeStream(opts.telescopeIp, opts.streamKey, opts.quality, opts.rtmpUrl, opts.musicUrl, opts.musicVolume);
    // Guarantee live:true reaches the renderer — startYouTubeStream already sends it
    // but send again here in case the earlier send was missed
    if (ffmpegProcess) {
      mainWindow?.webContents.send('stream:status', { live: true });
    }
    return { success: true };
  } catch(e) {
    mainWindow?.webContents.send('stream:status', { live: false, error: e.message });
    return { success: false, error: e.message };
  }
});
ipcMain.handle('stream:stop', async () => {
  stopStreaming();
  // Send status directly from IPC handler — guaranteed to reach renderer
  mainWindow?.webContents.send('stream:status', { live: false });
  return { success: true };
});
ipcMain.handle('stream:switchRadio', async (_, url)  => { switchRadioStation(url); return { success:true }; });
ipcMain.handle('stream:setVolume',   async (_, vol)  => { setRadioVolume(vol);      return { success:true }; });
ipcMain.handle('stream:checkFFmpeg', async ()        => new Promise(res => exec('ffmpeg -version', (err,out) => res(err ? {available:false} : {available:true, version:(out.match(/ffmpeg version ([^\s]+)/)||[])[1]||'?'}))));

// ── Recording ─────────────────────────────────────────────────────────────────
ipcMain.handle('record:start', async (_, { telescopeIp, quality }) => {
  const r = await dialog.showSaveDialog(mainWindow, {
    title: 'Save Recording',
    defaultPath: path.join(app.getPath('videos'), `origin_${ts()}.mp4`),
    filters: [{ name:'MP4 Video', extensions:['mp4'] }],
  });
  if (r.canceled) return { success:false, canceled:true };
  try { await startRecording(telescopeIp, quality, r.filePath); return { success:true, filePath:r.filePath }; }
  catch(e) { return { success:false, error:e.message }; }
});

ipcMain.handle('record:stop',     async () => { stopRecording(); return { success:true }; });

ipcMain.handle('record:snapshot', async (_, { telescopeIp }) => {
  const r = await dialog.showSaveDialog(mainWindow, {
    title: 'Save Snapshot',
    defaultPath: path.join(app.getPath('pictures'), `origin_${ts()}.jpg`),
    filters: [{ name:'JPEG Image', extensions:['jpg'] }],
  });
  if (r.canceled) return { success:false, canceled:true };
  try { await captureSnapshot(telescopeIp, r.filePath); return { success:true, filePath:r.filePath }; }
  catch(e) { return { success:false, error:e.message }; }
});

ipcMain.handle('app:openExternal', async (_, url)      => shell.openExternal(url));
ipcMain.handle('app:revealFile',   async (_, filePath) => {
  // If relative path, resolve from app install dir
  const resolved = path.isAbsolute(filePath)
    ? filePath
    : path.join(path.dirname(path.dirname(path.dirname(__dirname))), filePath);
  // For PDFs open directly, otherwise show in folder
  if (resolved.endsWith('.pdf')) shell.openPath(resolved);
  else shell.showItemInFolder(resolved);
});

ipcMain.handle('app:getLocation', async () => {
  // Read saved location (set from telescope RunInitialize or manually in Settings)
  try {
    const saved = JSON.parse(fs.readFileSync(path.join(app.getPath('userData'), 'location.json'), 'utf8'));
    if (saved?.lat !== undefined) return saved;
  } catch(_) {}
  return null;
});

ipcMain.handle('app:saveLocation', async (_, loc) => {
  try {
    fs.writeFileSync(path.join(app.getPath('userData'), 'location.json'), JSON.stringify(loc), 'utf8');
    return { success: true };
  } catch(e) { return { success: false, error: e.message }; }
});

ipcMain.handle('app:getWeather', async (_, { lat, lon }) => {
  // Open-Meteo — free, no API key, 1km resolution weather data
  // We fetch current conditions relevant to astronomy:
  //   cloud_cover, visibility, wind_speed_10m, precipitation,
  //   relative_humidity_2m, dew_point_2m, temperature_2m
  return new Promise((resolve) => {
    const params = [
      'current=temperature_2m,relative_humidity_2m,dew_point_2m,precipitation',
      'current=cloud_cover,visibility,wind_speed_10m,wind_gusts_10m,weather_code',
      `latitude=${lat.toFixed(4)}`,
      `longitude=${lon.toFixed(4)}`,
      'wind_speed_unit=mph',
      'temperature_unit=fahrenheit',
      'timezone=auto',
    ].join('&');
    const url = `https://api.open-meteo.com/v1/forecast?${params}`;
    const https = require('https');
    let data = '';
    const req = https.get(url, (res) => {
      res.on('data', chunk => { data += chunk; });
      res.on('end', () => {
        try {
          const json = JSON.parse(data);
          resolve({ success: true, data: json.current, units: json.current_units });
        } catch(e) {
          resolve({ success: false, error: e.message });
        }
      });
    });
    req.on('error', (e) => resolve({ success: false, error: e.message }));
    req.setTimeout(8000, () => { req.destroy(); resolve({ success: false, error: 'timeout' }); });
  });
});

// ── Music Search (Internet Archive) ──────────────────────────────────────────
// Internet Archive hosts millions of CC-licensed audio files.
// The search API requires no key and returns direct MP3 URLs.
// ── Telescope Helpers ─────────────────────────────────────────────────────────
function checkTcpPort(ip, port) {
  return new Promise(res => {
    const s = new net.Socket();
    s.setTimeout(700);
    s.connect(port, ip, () => { s.destroy(); res(true); });
    s.on('error',   () => res(false));
    s.on('timeout', () => { s.destroy(); res(false); });
  });
}

function getTelescopeInfo(ip) {
  // The Celestron Origin uses a WebSocket API, not ALPACA HTTP.
  // We get info from the initial WebSocket handshake messages,
  // but for a quick connect we use what we know from packet analysis
  // and fall back to ALPACA endpoints.
  const fetchVal = (endpoint) => new Promise(res => {
    http.get(`http://${ip}/api/v1/telescope/0/${endpoint}`, { timeout: 3000 }, r => {
      let d = ''; r.on('data', c => d += c);
      r.on('end', () => { try { res(JSON.parse(d).Value || null); } catch { res(null); } });
    }).on('error', () => res(null));
  });

  // Get firmware version and name by connecting to SmartScope WebSocket
  // and actively requesting GetVersion + GetModel
  const fetchSmartScopeVersion = () => new Promise(res => {
    const WS = require('ws');
    const ws = new WS(`ws://${ip}/SmartScope-1.0/mountControlEndpoint`, { handshakeTimeout: 5000 });
    let version = null;
    let name    = 'Celestron Origin';
    const timer = setTimeout(() => { try{ws.close();}catch(_){} res({ version, name }); }, 8000);

    ws.on('open', () => {
      ws.send(JSON.stringify({ Command:'GetVersion', Destination:'System', Source:'OriginMobileApp', SequenceID:1, Type:'Command', ExpiredAt: Date.now()+8000 }));
      ws.send(JSON.stringify({ Command:'GetModel',   Destination:'System', Source:'OriginMobileApp', SequenceID:2, Type:'Command', ExpiredAt: Date.now()+8000 }));
    });

    ws.on('message', (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.Command === 'GetVersion') {
          // Response has both Number ("1.3.5330") and Version ("1.3.5330 (OriginCore = ...)")
          version = msg.Number || msg.Version || null;
          // Strip the long build string if present — keep just the version number
          if (version && version.includes(' ')) version = version.split(' ')[0];
        }
        if (msg.Command === 'GetModel' && msg.Devices) {
          name = 'Celestron Origin';
        }
        if (msg.Command === 'GetMountConfig' && msg.Name) {
          name = msg.Name;
        }
        if (version) { clearTimeout(timer); try{ws.close();}catch(_){} res({ version, name }); }
      } catch(_) {}
    });
    ws.on('error', () => { clearTimeout(timer); res({ version, name }); });
  });

  return Promise.all([
    fetchVal('name'),
    fetchVal('driverversion'),
    fetchSmartScopeVersion(),
  ]).then(([alpacaName, alpacaVersion, smartScope]) => {
    const name     = smartScope.name || alpacaName || 'Celestron Origin';
    const firmware = smartScope.version || alpacaVersion || 'Unknown';
    return { model: name, firmware, ip };
  });
}

function getTelescopeStatus(ip) {
  // Read status from SmartScope WebSocket — telescope pushes GetStatus notifications
  return new Promise(res => {
    const WS = require('ws');
    const ws = new WS(`ws://${ip}/SmartScope-1.0/mountControlEndpoint`, { handshakeTimeout: 3000 });
    const status = { RA: null, Dec: null, Altitude: null, Azimuth: null, Tracking: null };
    let gotMount = false;

    const done = () => { ws.close(); res(status); };
    const timer = setTimeout(done, 3000);

    ws.on('message', (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.Source === 'Mount' && msg.Command === 'GetStatus') {
          // RA/Dec from encoder angles
          if (msg.Enc0 !== undefined) status.RA       = (msg.Enc0 * 12 / Math.PI).toFixed(4);
          if (msg.Enc1 !== undefined) status.Dec      = (msg.Enc1 * 180 / Math.PI).toFixed(4);
          if (msg.IsTracking !== undefined) status.Tracking = msg.IsTracking;
          gotMount = true;
        }
        if (msg.Source === 'OrientationSensor' && msg.Command === 'GetStatus') {
          if (msg.Altitude !== undefined) status.Altitude = msg.Altitude.toFixed(2);
        }
        if (gotMount) { clearTimeout(timer); done(); }
      } catch(_) {}
    });

    ws.on('error', () => { clearTimeout(timer); res(status); });
    ws.on('close', () => { clearTimeout(timer); res(status); });
  });
}

// ── Fetch All Telescope Settings ──────────────────────────────────────────────
// Sends all settings queries in one WebSocket connection and collects responses.
// Also captures broadcast Notifications (e.g. Environment status) that arrive
// during the window since those don't have matching SequenceIDs.
function fetchAllTelescopeSettings(ip) {
  return new Promise((resolve) => {
    const WS = require('ws');
    const ws = new WS(`ws://${ip}/SmartScope-1.0/mountControlEndpoint`, { handshakeTimeout: 5000 });
    const results = {};
    let seqId = 500;

    const cmds = [
      { Command: 'GetVersion',                 Destination: 'System'                       },
      { Command: 'GetModel',                   Destination: 'System'                       },
      { Command: 'GetUpdateChannel',           Destination: 'System'                       },
      { Command: 'HasUpdateAvailable',         Destination: 'System', ForceCheck: false    },
      { Command: 'GetSerialNumber',            Destination: 'FactoryCalibrationController' },
      { Command: 'GetStatus',                  Destination: 'FactoryCalibrationController' },
      { Command: 'GetCameraInfo',              Destination: 'Camera'                       },
      { Command: 'GetCaptureParameters',       Destination: 'Camera'                       },
      { Command: 'GetMountConfig',             Destination: 'Mount'                        },
      { Command: 'GetStatus',                  Destination: 'Mount'                        },
      { Command: 'GetStatus',                  Destination: 'DewHeater'                    },
      { Command: 'GetSensors',                 Destination: 'Environment'                  },
      { Command: 'GetStatus',                  Destination: 'Environment'                  },
      { Command: 'GetFocuserAdvancedSettings', Destination: 'Focuser'                      },
      { Command: 'GetStatus',                  Destination: 'Focuser'                      },
      { Command: 'GetPositionLimits',          Destination: 'Focuser'                      },
      { Command: 'GetForceDirectConnect',      Destination: 'Network'                      },
      { Command: 'HasInternetConnection',      Destination: 'Network'                      },
      { Command: 'GetBrightnessLevel',         Destination: 'LedRing'                      },
    ];

    // Track by seqId for direct responses
    const expectedSeqs = new Set();
    // Track which Source:Command keys we still need from responses
    const expectedKeys = new Set(cmds.map(c => `${c.Destination}:${c.Command}`));

    const done = () => { try{ws.close();}catch(_){} resolve(results); };
    const timer = setTimeout(done, 8000);

    ws.on('open', () => {
      for (const cmd of cmds) {
        const id = ++seqId;
        expectedSeqs.add(id);
        ws.send(JSON.stringify({
          ...cmd,
          Source:     'OriginMobileApp',
          SequenceID: id,
          Type:       'Command',
        }));
      }
    });

    ws.on('message', (data) => {
      try {
        const msg = JSON.parse(data.toString());
        const key = `${msg.Source}:${msg.Command}`;

        // Accept: direct responses to our commands OR useful notifications
        const isOurResponse  = expectedSeqs.has(msg.SequenceID);
        const isNotification = msg.Type === 'Notification' && expectedKeys.has(key);

        if (isOurResponse || isNotification) {
          if (isOurResponse) expectedSeqs.delete(msg.SequenceID);
          expectedKeys.delete(key);
          // Don't overwrite a direct Response with a Notification
          if (!results[key] || msg.Type === 'Response') results[key] = msg;
          if (expectedKeys.size === 0) { clearTimeout(timer); done(); }
        }
      } catch(_) {}
    });

    ws.on('error', () => { clearTimeout(timer); resolve(results); });
  });
}

// ── SmartScope WebSocket Command Sender ───────────────────────────────────────
// All commands are JSON WebSocket messages with Type:"Command"
// Confirmed from packet capture analysis.

let cmdSeqId = 100;

function sendSmartScopeCommand(ip, destination, extraParams = {}) {
  return new Promise((resolve) => {
    const seqId = ++cmdSeqId;

    const sendMsg = (ws) => {
      const msg = {
        Destination: destination,
        SequenceID:  seqId,
        Source:      'OriginMobileApp',
        Type:        'Command',
        ...extraParams,
      };
      ws.send(JSON.stringify(msg));
    };

    // Use the existing originWs if available — avoids opening a 3rd WebSocket
    // which the telescope may reject
    if (originWs && originWs.readyState === 1) {
      const timeout = setTimeout(() => {
        originWs.removeListener('message', onMsg);
        resolve({ ok: true });
      }, 5000);

      const onMsg = (data) => {
        try {
          const msg = JSON.parse(data.toString());
          if (msg.SequenceID === seqId) {
            clearTimeout(timeout);
            originWs.removeListener('message', onMsg);
            resolve(msg);
          }
        } catch(_) {}
      };

      originWs.on('message', onMsg);
      sendMsg(originWs);
    } else {
      // Fallback: open a temporary WebSocket if not connected
      const WS = require('ws');
      const ws = new WS(`ws://${ip}/SmartScope-1.0/mountControlEndpoint`, { handshakeTimeout: 5000 });
      const timeout = setTimeout(() => { try{ws.close();}catch(_){} resolve({ ok: true }); }, 5000);

      ws.on('open', () => { sendMsg(ws); });
      ws.on('message', (data) => {
        try {
          const msg = JSON.parse(data.toString());
          if (msg.SequenceID === seqId) {
            clearTimeout(timeout);
            ws.close();
            resolve(msg);
          }
        } catch(_) {}
      });
      ws.on('error', (err) => { clearTimeout(timeout); resolve({ ok: false, error: err.message }); });
      ws.on('close', () => { clearTimeout(timeout); resolve({ ok: true }); });
    }
  });
}

function sendTelescopeCommand(ip, command, params = {}) {
  // Map commands to the confirmed SmartScope WebSocket protocol
  switch (command.toLowerCase()) {

    // D-pad slew: AltRate/AzmRate -9..9, 0=stop
    case 'movingrate': {
      const dir = (params.Direction || '').toLowerCase();
      const rate = params.Rate || 9;
      const AltRate = dir === 'north' ? rate : dir === 'south' ? -rate : 0;
      const AzmRate = dir === 'east'  ? rate : dir === 'west'  ? -rate : 0;
      return sendSmartScopeCommand(ip, 'Mount', { Command: 'Slew', AltRate, AzmRate });
    }

    // Stop: send Slew with both rates = 0
    case 'abortslew':
      return sendSmartScopeCommand(ip, 'Mount', { Command: 'Slew', AltRate: 0, AzmRate: 0 });

    // GoTo RA/Dec
    case 'slewtocoordinates':
      return sendSmartScopeCommand(ip, 'TaskController', {
        Command: 'GotoRaDec',
        Ra:  params.RightAscension,
        Dec: params.Declination,
      });

    // GoTo named object
    case 'slewtoobject':
      return sendSmartScopeCommand(ip, 'TaskController', {
        Command:    'GotoObject',
        ObjectName: params.Target,
      });

    // Tracking
    case 'tracking':
      return sendSmartScopeCommand(ip, 'Mount', {
        Command: params.Tracking ? 'StartTracking' : 'StopTracking',
      });

    // Focuser
    case 'focuser/move':
      return sendSmartScopeCommand(ip, 'Focuser', {
        Command: 'Move',
        Steps:   params.Position,
      });

    // Park
    case 'park':
      return sendSmartScopeCommand(ip, 'TaskController', { Command: 'Park' });

    // Initialize telescope (same as "Initialize" in the Celestron mobile app)
    // Requires Date, Time, TimeZone, Latitude and Longitude
    case 'initialize': {
      const now = new Date();
      const pad = n => String(n).padStart(2, '0');
      const date = `${pad(now.getDate())} ${pad(now.getMonth()+1)} ${now.getFullYear()}`;
      const time = `${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
      const tz = Intl.DateTimeFormat().resolvedOptions().timeZone || 'America/New_York';
      // Load saved location (set from previous telescope session or manually in Settings)
      let lat = params.Latitude  || 0;
      let lon = params.Longitude || 0;
      try {
        const { app: electronApp } = require('electron');
        const locPath = path.join(electronApp.getPath('userData'), 'location.json');
        if (fs.existsSync(locPath)) {
          const loc = JSON.parse(fs.readFileSync(locPath, 'utf8'));
          if (loc.lat) lat = loc.lat * Math.PI / 180; // convert degrees to radians
          if (loc.lon) lon = loc.lon * Math.PI / 180;
        }
      } catch(_) {}
      return sendSmartScopeCommand(ip, 'TaskController', {
        Command:        'RunInitialize',
        Date:           date,
        Time:           time,
        TimeZone:       tz,
        Latitude:       lat,
        Longitude:      lon,
        FakeInitialize: params.DemoMode || false,
      });
    }

    // Start stacking — SetEnableAuto goes to LiveStream (confirmed from PCAP)
    // No Enable param — it's a toggle that enables auto/stacking mode
    case 'startauto':
      return sendSmartScopeCommand(ip, 'LiveStream', { Command: 'SetEnableAuto' });

    // Stop stacking — disable auto, re-enable live single frames
    case 'stopauto':
      return sendSmartScopeCommand(ip, 'LiveStream', { Command: 'SetEnableManual' });

    // Manual capture mode
    case 'startmanual':
      return sendSmartScopeCommand(ip, 'LiveStream', { Command: 'SetEnableManual' });

    case 'stopmanual':
      return sendSmartScopeCommand(ip, 'LiveStream', { Command: 'SetEnableAuto' });

    default:
      return sendSmartScopeCommand(ip, 'Mount', { Command: command, ...params });
  }
}

// ── YouTube OAuth — Device Flow (TV-style QR login) ──────────────────────────
// Device Flow lets users approve access on their phone by scanning a QR code.
// The desktop app polls for the token — no redirect URI or client secret needed
// in the traditional sense. Credentials are bundled with the app.
//
// TO SET UP: Create a free Google Cloud project, enable YouTube Data API v3,
// create an OAuth client ID of type "TVs and Limited Input devices".
// Paste the client ID and secret into the oauthConfig below.
// These are safe to bundle — Google explicitly allows it for installed/device apps.

let oauthConfig = {
  clientId:     '',  // bundled at build time — TVs/Limited Input OAuth client
  clientSecret: '',
  redirectUri:  'http://127.0.0.1:42813/oauth/callback',
  scopes: [
    'https://www.googleapis.com/auth/youtube',
    'https://www.googleapis.com/auth/youtube.upload',
  ],
};

let deviceFlowWindow = null;

ipcMain.handle('auth:signIn', async () => {
  try {
    if (!oauthConfig.clientId) {
      return { success: false, error: 'No OAuth credentials configured. Go to Settings → YouTube Sign-In Setup and add your Google Cloud Client ID and Secret.' };
    }
    // Try device flow (QR code) first — works with "TVs and Limited Input devices" client type
    // Falls back to browser flow for "Desktop app" client type
    try {
      const result = await startDeviceFlow();
      return result;
    } catch(e) {
      if (e.message.includes('invalid_client') || e.message.includes('Invalid client')) {
        // Client type doesn't support device flow — use browser OAuth instead
        const result = await startBrowserOAuthFlow();
        return result;
      }
      throw e;
    }
  } catch(e) {
    return { success: false, error: e.message };
  }
});

ipcMain.handle('auth:signOut', async () => {
  oauthTokens = null;
  try { fs.unlinkSync(tokenPath()); } catch(_){}
  try {
    const { session } = require('electron');
    await session.fromPartition('persist:youtube').clearStorageData();
  } catch(_) {}
  return { success: true };
});

ipcMain.handle('auth:getLiveStreamKey', async () => {
  try { return { success: true, streamKey: await getOrCreateStreamKey() }; }
  catch(e) { return { success: false, error: e.message }; }
});

// ── Device Flow: show QR code + poll for token ────────────────────────────────
function startDeviceFlow() {
  return new Promise(async (resolve, reject) => {
    // Step 1: request a device code
    let deviceData;
    try {
      deviceData = await postForm('https://oauth2.googleapis.com/device/code', {
        client_id: oauthConfig.clientId,
        scope: oauthConfig.scopes.join(' '),
      });
    } catch(e) {
      return reject(new Error('Could not contact Google: ' + e.message));
    }

    if (deviceData.error) {
      return reject(new Error(deviceData.error_description || deviceData.error));
    }

    const { device_code, user_code, verification_url, expires_in, interval } = deviceData;
    const pollInterval = (interval || 5) * 1000;
    const expiresAt = Date.now() + expires_in * 1000;

    // Step 2: show a window with QR code + the code to enter
    if (deviceFlowWindow && !deviceFlowWindow.isDestroyed()) deviceFlowWindow.close();
    deviceFlowWindow = new BrowserWindow({
      width: 420, height: 520,
      parent: mainWindow, modal: true,
      title: 'Sign in to YouTube',
      backgroundColor: '#0f1117',
      webPreferences: { nodeIntegration: false, contextIsolation: true },
    });
    deviceFlowWindow.setMenuBarVisibility(false);

    const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=200x200&data=${encodeURIComponent(verification_url + '?user_code=' + user_code)}`;

    deviceFlowWindow.loadURL(`data:text/html;charset=utf-8,${encodeURIComponent(`<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<style>
  * { margin:0; padding:0; box-sizing:border-box; }
  body { background:#0f1117; color:#e8eaed; font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;
         display:flex; flex-direction:column; align-items:center; justify-content:center; min-height:100vh; padding:28px; text-align:center; }
  h2 { font-size:17px; font-weight:600; margin-bottom:6px; }
  p  { font-size:13px; color:#9aa0a6; margin-bottom:18px; line-height:1.5; }
  .qr { background:#fff; padding:12px; border-radius:10px; margin-bottom:18px; }
  .qr img { display:block; width:200px; height:200px; }
  .code-box { background:#1e2130; border:1px solid #3c4043; border-radius:8px; padding:12px 20px; margin-bottom:14px; }
  .code { font-size:26px; font-weight:700; letter-spacing:4px; color:#4fc3f7; font-family:monospace; }
  .url  { font-size:12px; color:#9aa0a6; margin-top:6px; }
  .hint { font-size:12px; color:#9aa0a6; }
  .yt   { color:#ff4444; font-weight:700; }
</style>
</head>
<body>
  <h2>Sign in to <span class="yt">YouTube</span></h2>
  <p>Scan the QR code or visit the URL below<br>on your phone or computer to approve access.</p>
  <div class="qr"><img src="${qrUrl}" alt="QR Code"/></div>
  <div class="code-box">
    <div class="code">${user_code}</div>
    <div class="url">${verification_url}</div>
  </div>
  <div class="hint">Waiting for approval…</div>
</body>
</html>`)}`);

    let polling = true;
    let resolved = false;

    const finish = (result) => {
      if (resolved) return; resolved = true; polling = false;
      if (deviceFlowWindow && !deviceFlowWindow.isDestroyed()) deviceFlowWindow.close();
      if (result.error) reject(new Error(result.error));
      else resolve(result);
    };

    deviceFlowWindow.on('closed', () => { deviceFlowWindow = null; if (!resolved) finish({ error: 'Sign-in cancelled' }); });

    // Step 3: poll for the token
    const poll = async () => {
      if (!polling) return;
      if (Date.now() > expiresAt) return finish({ error: 'QR code expired. Please try again.' });

      try {
        const resp = await postForm('https://oauth2.googleapis.com/token', {
          client_id: oauthConfig.clientId,
          client_secret: oauthConfig.clientSecret,
          device_code,
          grant_type: 'urn:ietf:params:oauth:grant-type:device_code',
        });

        if (resp.access_token) {
          const channelName = await fetchChannelName(resp.access_token).catch(() => 'YouTube Account');
          oauthTokens = {
            access_token:  resp.access_token,
            refresh_token: resp.refresh_token,
            expiry:        Date.now() + resp.expires_in * 1000,
            channelName,
          };
          saveTokens(oauthTokens);
          finish({ success: true, channelName });
        } else if (resp.error === 'authorization_pending' || resp.error === 'slow_down') {
          setTimeout(poll, resp.error === 'slow_down' ? pollInterval * 2 : pollInterval);
        } else if (resp.error === 'expired_token') {
          finish({ error: 'QR code expired. Please try again.' });
        } else {
          finish({ error: resp.error_description || resp.error || 'Unknown error' });
        }
      } catch(e) {
        setTimeout(poll, pollInterval); // retry on network error
      }
    };

    setTimeout(poll, pollInterval);
  });
}



// ── Browser OAuth Flow (fallback for "Desktop app" client type) ───────────────
// Used when device flow fails with invalid_client — Desktop app clients use
// a local redirect URI instead of the device code endpoint.
function startBrowserOAuthFlow() {
  return new Promise((resolve, reject) => {
    // Close any existing callback server
    if (oauthCallbackServer) { try { oauthCallbackServer.close(); } catch(_){} oauthCallbackServer = null; }

    oauthCallbackServer = http.createServer(async (req, res) => {
      const url  = new URL(req.url, 'http://127.0.0.1:42813');
      const code = url.searchParams.get('code');
      const err  = url.searchParams.get('error');

      res.writeHead(200, { 'Content-Type': 'text/html' });
      res.end(`<!DOCTYPE html><html><head><style>
        body{background:#0f1117;color:#e8eaed;font-family:sans-serif;display:flex;align-items:center;justify-content:center;height:100vh;text-align:center;}
        h2{color:#4fc3f7;} p{color:#9aa0a6;}
      </style></head><body><h2>${err ? '❌ Sign-in cancelled' : '✓ Signed in!'}</h2>
      <p>${err ? 'You can close this window.' : 'You can close this window and return to the app.'}</p></body></html>`);

      if (oauthCallbackServer) { oauthCallbackServer.close(); oauthCallbackServer = null; }
      if (authWindow && !authWindow.isDestroyed()) setTimeout(() => { try{authWindow.close();}catch(_){} }, 1000);

      if (err || !code) return reject(new Error(err || 'No code returned'));

      try {
        const tokens = await exchangeCode(code);
        const channelName = await fetchChannelName(tokens.access_token).catch(() => 'YouTube Account');
        oauthTokens = { ...tokens, channelName };
        saveTokens(oauthTokens);
        resolve({ success: true, channelName });
      } catch(e) {
        reject(e);
      }
    });

    let authWindow = null;
    oauthCallbackServer.listen(42813, '127.0.0.1', () => {
      const params = new URLSearchParams({
        client_id:     oauthConfig.clientId,
        redirect_uri:  oauthConfig.redirectUri,
        response_type: 'code',
        scope:         oauthConfig.scopes.join(' '),
        access_type:   'offline',
        prompt:        'consent',
      });

      authWindow = new BrowserWindow({
        width: 500, height: 680,
        parent: mainWindow, modal: true,
        title: 'Sign in to YouTube',
        backgroundColor: '#fff',
        webPreferences: { nodeIntegration: false, contextIsolation: true },
      });
      authWindow.setMenuBarVisibility(false);
      authWindow.loadURL(`https://accounts.google.com/o/oauth2/v2/auth?${params}`);
      authWindow.on('closed', () => {
        authWindow = null;
        if (oauthCallbackServer) { oauthCallbackServer.close(); oauthCallbackServer = null; reject(new Error('Sign-in cancelled')); }
      });
    });

    oauthCallbackServer.on('error', reject);
  });
}


function exchangeCode(code) {
  return postForm('https://oauth2.googleapis.com/token', {
    code, client_id:oauthConfig.clientId, client_secret:oauthConfig.clientSecret,
    redirect_uri:oauthConfig.redirectUri, grant_type:'authorization_code',
  }).then(d => {
    if (d.error) throw new Error(d.error_description || d.error);
    return { access_token:d.access_token, refresh_token:d.refresh_token, expiry:Date.now()+(d.expires_in*1000) };
  });
}

function refreshToken() {
  if (!oauthTokens?.refresh_token) return Promise.resolve(false);
  return postForm('https://oauth2.googleapis.com/token', {
    client_id:oauthConfig.clientId, client_secret:oauthConfig.clientSecret,
    refresh_token:oauthTokens.refresh_token, grant_type:'refresh_token',
  }).then(d => {
    if (!d.access_token) return false;
    oauthTokens.access_token = d.access_token;
    oauthTokens.expiry       = Date.now()+(d.expires_in*1000);
    saveTokens(oauthTokens); return true;
  }).catch(()=>false);
}

function fetchChannelName(token) {
  return httpsGet('https://www.googleapis.com/youtube/v3/channels?part=snippet&mine=true', token)
    .then(d => d.items?.[0]?.snippet?.title || 'YouTube Channel').catch(()=>'YouTube Channel');
}

async function getOrCreateStreamKey() {
  if (!oauthTokens) throw new Error('Not signed in');
  if (Date.now() > oauthTokens.expiry - 60000) { const ok=await refreshToken(); if(!ok) throw new Error('Session expired'); }
  const token = oauthTokens.access_token;

  // Step 1: Get or create a liveStream (the RTMP ingest endpoint)
  let streamId = null;
  let streamKey = null;
  const streams = await httpsGet('https://www.googleapis.com/youtube/v3/liveStreams?part=snippet,cdn,status&mine=true', token);
  if (streams.items?.length) {
    const active = streams.items.find(s => s.status?.streamStatus !== 'inactive') || streams.items[0];
    streamKey = active.cdn?.ingestionInfo?.streamName;
    streamId  = active.id;
  }
  if (!streamKey) {
    const created = await httpsPost('https://www.googleapis.com/youtube/v3/liveStreams?part=snippet,cdn', token, {
      snippet: { title: 'Celestron Origin Live' },
      cdn: { frameRate: 'variable', ingestionType: 'rtmp', resolution: 'variable' },
    });
    streamKey = created.cdn?.ingestionInfo?.streamName;
    streamId  = created.id;
    if (!streamKey) throw new Error('YouTube did not return a stream key');
  }

  // Step 2: Get or create a liveBroadcast bound to this stream
  // Look for an existing broadcast that is not complete
  const now = new Date();
  const broadcasts = await httpsGet(
    'https://www.googleapis.com/youtube/v3/liveBroadcasts?part=id,status,contentDetails&mine=true&broadcastStatus=upcoming', token
  );
  let broadcastId = broadcasts.items?.[0]?.id;

  if (!broadcastId) {
    // Create a new broadcast starting now
    const scheduledStart = new Date(now.getTime() + 30000).toISOString(); // 30s from now
    const broadcast = await httpsPost(
      'https://www.googleapis.com/youtube/v3/liveBroadcasts?part=snippet,status,contentDetails', token, {
        snippet: {
          title: 'Celestron Origin — Live View',
          scheduledStartTime: scheduledStart,
        },
        status: {
          privacyStatus: 'public',
          selfDeclaredMadeForKids: false,
        },
        contentDetails: {
          enableAutoStart: true,
          enableAutoStop: true,
          enableDvr: true,
          recordFromStart: true,
          startWithSlate: false,
        },
      }
    );
    broadcastId = broadcast.id;
    if (!broadcastId) throw new Error('YouTube did not create a broadcast');
  }

  // Step 3: Bind the broadcast to the stream if not already bound
  if (streamId && broadcastId) {
    await httpsPost(
      `https://www.googleapis.com/youtube/v3/liveBroadcasts/bind?id=${broadcastId}&part=id,contentDetails&streamId=${streamId}`,
      token, {}
    ).catch(() => {}); // ignore bind errors — may already be bound
  }

  return streamKey;
}

// ── FFmpeg ────────────────────────────────────────────────────────────────────
// ── Frame pipe helper ─────────────────────────────────────────────────────────
// The Origin delivers ~1fps JPEG frames via WebSocket notifications.
// We pipe each frame into FFmpeg's stdin using the image2pipe demuxer,
// which lets FFmpeg encode a proper continuous video stream from discrete frames.

let streamWs            = null;
let streamPipeActive    = false;
let streamFrameListener = null;

function stopFramePipe() {
  streamPipeActive = false;
  // Remove listener from main WebSocket
  if (streamFrameListener && originWs) {
    try { originWs.off('message', streamFrameListener); } catch(_) {}
  }
  streamFrameListener = null;
  // Also close dedicated stream WS if one was opened
  if (streamWs) { try { streamWs.close(); } catch(_) {} streamWs = null; }
}

function startFramePipe(telescopeIp, ffmpegProc, onStop) {
  stopFramePipe();
  streamPipeActive = true;

  const baseUrl = `http://${telescopeIp}/SmartScope-1.0/dev2/`;
  let fetching = false;

  const fetchFrame = (fileLocation) => {
    if (fetching || !streamPipeActive) return;
    fetching = true;
    const url = new URL(baseUrl + fileLocation);
    const req = http.get({ hostname: url.hostname, port: parseInt(url.port)||80, path: url.pathname, timeout: 5000 }, res => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end', () => {
        fetching = false;
        if (!streamPipeActive) return;
        const buf = Buffer.concat(chunks);
        if (buf.length > 100 && res.statusCode === 200) {
          try {
            if (ffmpegProc.stdin.writable) ffmpegProc.stdin.write(buf);
            else stopFramePipe();
          } catch(_) { stopFramePipe(); }
        }
      });
      res.on('error', () => { fetching = false; });
    });
    req.on('error', () => { fetching = false; });
    req.on('timeout', () => { req.destroy(); fetching = false; });
    req.end();
  };

  // Reuse the existing main telescope WebSocket instead of opening a second connection
  // This avoids the stream failing if the telescope rejects a second WS connection
  streamFrameListener = (data) => {
    if (!streamPipeActive) return;
    try {
      const msg = JSON.parse(data.toString());
      if (msg.Command === 'NewImageReady' && msg.FileLocation) {
        fetchFrame(msg.FileLocation);
      }
    } catch(_) {}
  };

  if (originWs && originWs.readyState === 1) {
    originWs.on('message', streamFrameListener);
  } else {
    // Fallback: open a dedicated WebSocket if main one isn't available
    const WS = require('ws');
    streamWs = new WS(`ws://${telescopeIp}/SmartScope-1.0/mountControlEndpoint`, { handshakeTimeout: 5000 });
    streamWs.on('message', streamFrameListener);
    streamWs.on('error', () => { stopFramePipe(); });
    streamWs.on('close', () => { stopFramePipe(); });
  }
}


function stopStreaming() {
  stopFramePipe();
  stopAudioProxy();
  if (ffmpegProcess) {
    const proc = ffmpegProcess;
    ffmpegProcess = null;
    try { proc.kill('SIGTERM'); } catch(_) {}
    // On Windows SIGTERM may not fire the close event reliably — send status directly
    mainWindow?.webContents.send('stream:status', { live: false });
  }
}

async function startYouTubeStream(telescopeIp, streamKey, quality, rtmpUrl, musicUrl, musicVolume) {
  stopStreaming();
  const q = qualityPreset(quality);
  const destination = rtmpUrl || `rtmp://a.rtmp.youtube.com/live2/${streamKey}`;
  const vol = Math.max(0, Math.min(100, musicVolume || 40)) / 100;

  let args;
  if (musicUrl) {
    // Start audio proxy — FFmpeg reads from localhost, we can swap the upstream anytime
    currentRadioUrl = musicUrl;
    currentVolume   = vol;
    const port = await startAudioProxy();
    const proxyUrl = `http://127.0.0.1:${port}/audio`;

    args = [
      '-f', 'image2pipe', '-vcodec', 'mjpeg', '-framerate', '1', '-i', 'pipe:0',
      // Read raw PCM from the proxy — volume already applied by transcoder
      '-f', 's16le', '-ar', '44100', '-ac', '2',
      '-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_delay_max', '10',
      '-i', proxyUrl,
      '-c:v', 'libx264', '-preset', 'veryfast', '-tune', 'zerolatency',
      '-b:v', q.vb, '-maxrate', q.vb, '-bufsize', `${parseInt(q.vb)*2}k`,
      '-vf', `scale=${q.w}:${q.h},fps=${q.fps}`,
      '-g', String(q.fps * 2),
      '-filter_complex', '[1:a]aresample=44100[aout]',
      '-map', '0:v', '-map', '[aout]',
      '-c:a', 'aac', '-b:a', q.ab, '-ar', '44100',
      '-f', 'flv', destination,
    ];
  } else {
    // No music — silent audio
    args = [
      '-f', 'image2pipe', '-vcodec', 'mjpeg', '-framerate', '1', '-i', 'pipe:0',
      '-f', 'lavfi', '-i', 'anullsrc=channel_layout=stereo:sample_rate=44100',
      '-c:v', 'libx264', '-preset', 'veryfast', '-tune', 'zerolatency',
      '-b:v', q.vb, '-maxrate', q.vb, '-bufsize', `${parseInt(q.vb)*2}k`,
      '-vf', `scale=${q.w}:${q.h},fps=${q.fps}`,
      '-g', String(q.fps * 2),
      '-c:a', 'aac', '-b:a', q.ab, '-ar', '44100',
      '-shortest',
      '-f', 'flv', destination,
    ];
  }

  return new Promise((res, rej) => {
    ffmpegProcess = spawn('ffmpeg', args);
    let started = false;
    let hadError = false;

    ffmpegProcess.stdin.on('error', () => {});

    ffmpegProcess.stderr.on('data', d => {
      const msg = d.toString();
      mainWindow?.webContents.send('stream:log', msg);
      // Detect successful RTMP connection — fire live immediately
      if (!started && (
        msg.includes('Output #0') ||
        msg.includes('frame=') ||
        msg.includes('muxing overhead') ||
        msg.includes('Press [q]')
      )) {
        started = true;
        res();
        mainWindow?.webContents.send('stream:status', { live: true });
      }
      // Detect fatal errors before connection
      if (!started && (
        msg.includes('Connection refused') ||
        msg.includes('Connection timed out') ||
        msg.includes('No route to host') ||
        msg.includes('Invalid data found') ||
        msg.includes('Error') && msg.includes('rtmp')
      )) {
        hadError = true;
      }
    });

    ffmpegProcess.on('error', e => {
      stopFramePipe();
      if (!started) rej(e);
      mainWindow?.webContents.send('stream:status', { live: false, error: e.message });
    });

    ffmpegProcess.on('close', code => {
      stopFramePipe();
      ffmpegProcess = null;
      const err = (code && code !== 0 && !started) ? 'FFmpeg exited before connecting' : null;
      mainWindow?.webContents.send('stream:status', { live: false, error: err });
    });

    startFramePipe(telescopeIp, ffmpegProcess, null);

    // After 8s with no error, assume FFmpeg is connected and waiting for frames
    setTimeout(() => {
      if (!started && !hadError && ffmpegProcess) {
        started = true;
        res();
        mainWindow?.webContents.send('stream:status', { live: true });
      }
    }, 8000);

    // Hard fallback at 25s
    setTimeout(() => {
      if (!started) { started = true; res(); }
    }, 25000);
  });
}

// ── Audio Proxy ───────────────────────────────────────────────────────────────
// A local HTTP server that runs a small FFmpeg transcoder subprocess.
// The transcoder decodes the radio MP3, applies volume, and outputs raw PCM.
// The main stream FFmpeg reads raw PCM from the local server.
// Volume changes and station switches both just restart the small transcoder —
// the main stream FFmpeg keeps running without any interruption.

let audioProxyServer  = null;
let audioProxyPort    = 0;
let audioTranscoder   = null;   // small FFmpeg process for radio → PCM
let currentRadioUrl   = null;
let currentVolume     = 0.4;
let activeProxyRes    = null;

function startAudioProxy() {
  return new Promise((resolve) => {
    if (audioProxyServer) { resolve(audioProxyPort); return; }

    audioProxyServer = http.createServer((req, res) => {
      if (req.url !== '/audio') { res.end(); return; }

      res.writeHead(200, {
        'Content-Type':  'audio/L16;rate=44100;channels=2',
        'Cache-Control': 'no-cache',
        'Connection':    'keep-alive',
      });

      activeProxyRes = res;
      if (currentRadioUrl) startTranscoder(currentRadioUrl, currentVolume, res);

      req.on('close', () => {
        if (activeProxyRes === res) {
          activeProxyRes = null;
          stopTranscoder();
        }
      });
    });

    audioProxyServer.listen(0, '127.0.0.1', () => {
      audioProxyPort = audioProxyServer.address().port;
      resolve(audioProxyPort);
    });
  });
}

function startTranscoder(url, vol, proxyRes) {
  stopTranscoder();
  if (!proxyRes || proxyRes.destroyed) return;

  // Small FFmpeg: decode radio MP3 → apply volume → output raw s16le PCM
  const proc = spawn('ffmpeg', [
    '-reconnect', '1', '-reconnect_streamed', '1', '-reconnect_delay_max', '5',
    '-i', url,
    '-af', `volume=${vol.toFixed(3)}`,
    '-f', 's16le', '-ar', '44100', '-ac', '2',
    'pipe:1',
  ]);

  proc.stdout.on('data', (chunk) => {
    if (proxyRes && !proxyRes.destroyed) {
      try { proxyRes.write(chunk); } catch(_) {}
    }
  });

  proc.stdin.on('error', () => {});
  proc.stderr.on('data', () => {}); // suppress FFmpeg output
  proc.on('error', () => {});
  proc.on('close', () => { if (audioTranscoder === proc) audioTranscoder = null; });

  audioTranscoder = proc;
}

function stopTranscoder() {
  if (audioTranscoder) {
    try { audioTranscoder.kill('SIGTERM'); } catch(_) {}
    audioTranscoder = null;
  }
}

function switchRadioStation(url) {
  currentRadioUrl = url;
  if (activeProxyRes && !activeProxyRes.destroyed) {
    startTranscoder(url, currentVolume, activeProxyRes);
  }
}

function setRadioVolume(vol) {
  currentVolume = vol;
  if (currentRadioUrl && activeProxyRes && !activeProxyRes.destroyed) {
    startTranscoder(currentRadioUrl, vol, activeProxyRes);
  }
}

function stopAudioProxy() {
  stopTranscoder();
  currentRadioUrl = null;
  if (activeProxyRes) { try { activeProxyRes.end(); } catch(_) {} activeProxyRes = null; }
  if (audioProxyServer) { try { audioProxyServer.close(); } catch(_) {} audioProxyServer = null; audioProxyPort = 0; }
}

function startRecording(telescopeIp, quality, outputPath) {
  stopRecording();
  const q = qualityPreset(quality);

  const args = [
    '-f', 'image2pipe', '-vcodec', 'mjpeg', '-framerate', '1', '-i', 'pipe:0',
    '-c:v', 'libx264', '-preset', 'veryfast',
    '-b:v', q.vb, '-maxrate', q.vb, '-bufsize', `${parseInt(q.vb)*2}k`,
    '-vf', `scale=${q.w}:${q.h}`,
    '-movflags', '+faststart', '-y', outputPath,
  ];

  return new Promise((res, rej) => {
    recordProcess = spawn('ffmpeg', args);
    let started = false;
    let recWs = null;
    let recFetching = false;

    recordProcess.stderr.on('data', d => {
      const msg = d.toString();
      if (!started && (msg.includes('frame=') || msg.includes('Output #0'))) {
        started = true; res();
        mainWindow?.webContents.send('record:status', { recording: true, filePath: outputPath });
      }
      mainWindow?.webContents.send('record:log', msg);
    });

    recordProcess.on('error', e => {
      if (recWs) { try{recWs.close();}catch(_){} recWs = null; }
      if (!started) rej(e);
      mainWindow?.webContents.send('record:status', { recording: false, error: e.message });
    });

    recordProcess.on('close', () => {
      if (recWs) { try{recWs.close();}catch(_){} recWs = null; }
      recordProcess = null;
      mainWindow?.webContents.send('record:status', { recording: false, saved: outputPath });
    });

    // Pipe frames for recording (separate WS from live view)
    const WS = require('ws');
    recWs = new WS(`ws://${telescopeIp}/SmartScope-1.0/mountControlEndpoint`, { handshakeTimeout: 5000 });
    const baseUrl = `http://${telescopeIp}/SmartScope-1.0/dev2/`;

    recWs.on('message', (data) => {
      try {
        const msg = JSON.parse(data.toString());
        if (msg.Command === 'NewImageReady' && msg.FileLocation && !recFetching) {
          recFetching = true;
          const url = new URL(baseUrl + msg.FileLocation);
          const req = http.get({ hostname: url.hostname, port: parseInt(url.port)||80, path: url.pathname, timeout: 5000 }, rsp => {
            const chunks = [];
            rsp.on('data', c => chunks.push(c));
            rsp.on('end', () => {
              recFetching = false;
              const buf = Buffer.concat(chunks);
              if (buf.length > 100 && rsp.statusCode === 200) {
                try { recordProcess?.stdin.write(buf); } catch(_) {}
              }
            });
            rsp.on('error', () => { recFetching = false; });
          });
          req.on('error', () => { recFetching = false; });
          req.end();
        }
      } catch(_) {}
    });

    setTimeout(() => { if (!started) res(); }, 8000);
  });
}

function stopRecording() {
  if (recordProcess) {
    try { recordProcess.stdin.end(); } catch(_){}
    setTimeout(() => { if (recordProcess) { recordProcess.kill('SIGTERM'); recordProcess = null; } }, 2000);
  }
}

function captureSnapshot(telescopeIp, outputPath) {
  // Fetch the most recent frame directly from the current frame URL
  const snapshotUrl = `http://${telescopeIp}/SmartScope-1.0/dev2/Images/Temp/0.jpg`;
  return new Promise((res, rej) => {
    const p = spawn('ffmpeg', ['-i', snapshotUrl, '-vframes', '1', '-q:v', '2', '-y', outputPath]);
    p.on('close', code => { if (code===0||fs.existsSync(outputPath)) res(); else rej(new Error(`FFmpeg exit ${code}`)); });
    p.on('error', rej);
    setTimeout(() => { p.kill(); res(); }, 5000);
  });
}

function buildFFmpegArgs(input, q, output) {
  return [
    '-re', '-i', input,
    '-c:v','libx264', '-preset','veryfast', '-tune','zerolatency',
    '-b:v',q.vb, '-maxrate',q.vb, '-bufsize',`${parseInt(q.vb)*2}k`,
    '-vf',`scale=${q.w}:${q.h},fps=${q.fps}`,
    '-g',String(q.fps*2),
    '-c:a','aac', '-b:a',q.ab, '-ar','44100',
    ...output,
  ];
}

function qualityPreset(q) {
  return ({
    '480p': {vb:'1000k',ab:'96k', fps:24,w:854, h:480 },
    '720p': {vb:'2500k',ab:'128k',fps:30,w:1280,h:720 },
    '1080p':{vb:'4500k',ab:'192k',fps:30,w:1920,h:1080},
  })[q] || {vb:'2500k',ab:'128k',fps:30,w:1280,h:720};
}

// ── HTTPS Helpers ─────────────────────────────────────────────────────────────
function httpsGet(url, token) {
  return new Promise((res,rej) => {
    const u = new URL(url);
    https.get({ hostname:u.hostname, path:u.pathname+u.search, headers:{ Authorization:`Bearer ${token}` } }, r => {
      let d=''; r.on('data',c=>d+=c); r.on('end',()=>{ try{res(JSON.parse(d));}catch{rej(new Error('Bad JSON'));} });
    }).on('error',rej);
  });
}

function httpsPost(url, token, body) {
  return new Promise((res,rej) => {
    const u = new URL(url);
    const b = JSON.stringify(body);
    const req = https.request({
      hostname:u.hostname, path:u.pathname+u.search, method:'POST',
      headers:{ Authorization:`Bearer ${token}`, 'Content-Type':'application/json', 'Content-Length':Buffer.byteLength(b) },
    }, r => { let d=''; r.on('data',c=>d+=c); r.on('end',()=>{ try{res(JSON.parse(d));}catch{rej(new Error('Bad JSON'));} }); });
    req.on('error',rej); req.write(b); req.end();
  });
}

function postForm(url, params) {
  return new Promise((res,rej) => {
    const u = new URL(url);
    const b = new URLSearchParams(params).toString();
    const req = https.request({
      hostname:u.hostname, path:u.pathname, method:'POST',
      headers:{'Content-Type':'application/x-www-form-urlencoded','Content-Length':Buffer.byteLength(b)},
    }, r => { let d=''; r.on('data',c=>d+=c); r.on('end',()=>{ try{res(JSON.parse(d));}catch{rej(new Error('Bad JSON'));} }); });
    req.on('error',rej); req.write(b); req.end();
  });
}

function closeAuthServer() { if(oauthCallbackServer){ oauthCallbackServer.close(); oauthCallbackServer=null; } }
function ts() { return new Date().toISOString().replace(/[:.]/g,'-'); }
