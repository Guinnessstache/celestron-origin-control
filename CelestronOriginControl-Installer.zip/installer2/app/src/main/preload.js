const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('telescopeAPI', {
  // Telescope
  discover:       ()        => ipcRenderer.invoke('telescope:discover'),
  connect:        ip        => ipcRenderer.invoke('telescope:connect',        ip),
  command:        payload   => ipcRenderer.invoke('telescope:command',        payload),
  getStatus:      ip        => ipcRenderer.invoke('telescope:getStatus',      ip),
  findStream:     ip        => ipcRenderer.invoke('telescope:findStream',     ip),
  scanPorts:      ip        => ipcRenderer.invoke('telescope:scanPorts',      ip),
  requestVersion:   ()   => ipcRenderer.invoke('telescope:requestVersion'),
  getAllSettings:  ip   => ipcRenderer.invoke('telescope:getAllSettings', ip),
  setSetting:      opts => ipcRenderer.invoke('telescope:setSetting', opts),

  // YouTube OAuth
  setOAuthConfig:    cfg => ipcRenderer.invoke('auth:setOAuthConfig',    cfg),
  getOAuthConfig:    ()  => ipcRenderer.invoke('auth:getOAuthConfig'),
  getAuthStatus:     ()  => ipcRenderer.invoke('auth:getStatus'),
  signIn:            ()  => ipcRenderer.invoke('auth:signIn'),
  signOut:           ()  => ipcRenderer.invoke('auth:signOut'),
  getLiveStreamKey:  ()  => ipcRenderer.invoke('auth:getLiveStreamKey'),

  // Streaming
  startStream:    opts => ipcRenderer.invoke('stream:start',       opts),
  stopStream:     ()   => ipcRenderer.invoke('stream:stop'),
  switchRadio:    url  => ipcRenderer.invoke('stream:switchRadio', url),
  setVolume:      vol  => ipcRenderer.invoke('stream:setVolume',   vol),
  checkFFmpeg:    ()   => ipcRenderer.invoke('stream:checkFFmpeg'),
  startProxy:     url  => ipcRenderer.invoke('stream:startProxy',  url),
  stopProxy:      ()   => ipcRenderer.invoke('stream:stopProxy'),
  startFrames:    (url, baseUrl, startFrame) => ipcRenderer.invoke('stream:startFrames', url, baseUrl, startFrame),
  stopFrames:     ()   => ipcRenderer.invoke('stream:stopFrames'),
  onFrame:        cb   => ipcRenderer.on('stream:frame',      (_, data) => cb(data)),
  onFrameError:   cb   => ipcRenderer.on('stream:frameError', (_, msg)  => cb(msg)),

  // Recording
  startRecording: opts => ipcRenderer.invoke('record:start',    opts),
  stopRecording:  ()   => ipcRenderer.invoke('record:stop'),
  snapshot:       opts => ipcRenderer.invoke('record:snapshot', opts),

  // Shell
  openExternal: url      => ipcRenderer.invoke('app:openExternal', url),
  revealFile:   filePath => ipcRenderer.invoke('app:revealFile',   filePath),
  getLocation:  ()       => ipcRenderer.invoke('app:getLocation'),
  saveLocation: loc      => ipcRenderer.invoke('app:saveLocation', loc),
  getWeather:   (lat, lon) => ipcRenderer.invoke('app:getWeather', { lat, lon }),

  // Event listeners
  onScanProgress:   cb => ipcRenderer.on('telescope:scanProgress', (_, d) => cb(d)),
  onDebug:          cb => ipcRenderer.on('telescope:debug',         (_, d) => cb(d)),
  onVersion:        cb => ipcRenderer.on('telescope:version',       (_, v) => cb(v)),
  onMountStatus:    cb => ipcRenderer.on('telescope:mountStatus',   (_, d) => cb(d)),
  onTaskStatus:     cb => ipcRenderer.on('telescope:taskStatus',    (_, d) => cb(d)),
  onImageType:      cb => ipcRenderer.on('telescope:imageType',     (_, d) => cb(d)),
  onImageMeta:      cb => ipcRenderer.on('telescope:imageMeta',     (_, d) => cb(d)),
  onLocation:       cb => ipcRenderer.on('telescope:location',      (_, d) => cb(d)),
  onStreamStatus:   cb => ipcRenderer.on('stream:status',          (_, d) => cb(d)),
  onStreamLog:      cb => ipcRenderer.on('stream:log',             (_, d) => cb(d)),
  onRecordStatus:   cb => ipcRenderer.on('record:status',          (_, d) => cb(d)),
  onRecordLog:      cb => ipcRenderer.on('record:log',             (_, d) => cb(d)),
});
