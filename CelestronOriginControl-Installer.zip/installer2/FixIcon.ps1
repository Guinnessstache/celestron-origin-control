
# Set icon via registry UserIconOverride - this always wins over shortcut properties
$lnkPath = [Environment]::GetFolderPath('Desktop') + '\Celestron Origin Control.lnk'
$icoPath  = "$env:LOCALAPPDATA\CelestronOriginControl\app\src\assets\telescope.ico"

# Method 1: Direct shortcut COM (already done in installer)
$sh = New-Object -ComObject WScript.Shell
$sc = $sh.CreateShortcut($lnkPath)
$sc.IconLocation = "$icoPath,0"
$sc.Save()
[Runtime.InteropServices.Marshal]::ReleaseComObject($sh) | Out-Null

# Method 2: Rebuild icon cache database entries via shell notification
$code = '''
using System; using System.Runtime.InteropServices;
public class ShellHelper {
    [DllImport("shell32.dll", CharSet=CharSet.Auto)]
    public static extern void SHChangeNotify(int wEventId, int uFlags, IntPtr dwItem1, IntPtr dwItem2);
    [DllImport("shell32.dll", CharSet=CharSet.Auto)]  
    public static extern int SHGetFileInfo(string pszPath, uint dwFileAttributes, ref SHFILEINFO psfi, uint cbFileInfo, uint uFlags);
    [StructLayout(LayoutKind.Sequential, CharSet=CharSet.Auto)]
    public struct SHFILEINFO { public IntPtr hIcon; public int iIcon; public uint dwAttributes; [MarshalAs(UnmanagedType.ByValTStr, SizeConst=260)] public string szDisplayName; [MarshalAs(UnmanagedType.ByValTStr, SizeConst=80)] public string szTypeName; }
}
'''
Add-Type -TypeDefinition $code -ErrorAction SilentlyContinue

# Kill icon cache files
Stop-Process -Name explorer -Force -ErrorAction SilentlyContinue
Start-Sleep -Milliseconds 500
$cacheDir = "$env:LOCALAPPDATA\Microsoft\Windows\Explorer"
Get-ChildItem $cacheDir -Filter "iconcache_*.db" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
Get-ChildItem $cacheDir -Filter "thumbcache_*.db" -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue

Start-Process explorer
Start-Sleep 1

# Notify shell of change to the specific file
[ShellHelper]::SHChangeNotify(0x00000080, 0x0005, [System.Runtime.InteropServices.Marshal]::StringToHGlobalAuto($lnkPath), [IntPtr]::Zero)
[ShellHelper]::SHChangeNotify(0x08000000, 0x0000, [IntPtr]::Zero, [IntPtr]::Zero)

Write-Host "Icon refresh complete. The planet icon should now appear." -ForegroundColor Green
