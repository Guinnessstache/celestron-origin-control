#Requires -Version 5.1
Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$AppVersion  = '2.0.0'
$InstallDir  = (Join-Path $env:LOCALAPPDATA 'CelestronOriginControl')
$NodeZipUrl  = 'https://nodejs.org/dist/v20.11.1/node-v20.11.1-win-x64.zip'
$NodeZipName = 'node-v20.11.1-win-x64.zip'
$FFmpegUrl   = 'https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip'
$NodeDir     = (Join-Path $InstallDir 'node')
$FFmpegDir   = (Join-Path $InstallDir 'ffmpeg')
$FFmpegBin   = (Join-Path $FFmpegDir 'bin')
$TempDir     = (Join-Path $env:TEMP 'CelestronInstall')
$LogFile     = (Join-Path $TempDir 'install.log')
$LaunchBat   = (Join-Path $InstallDir 'Launch.bat')
$LaunchVbs   = (Join-Path $InstallDir 'Launch.vbs')
$DesktopLink = (Join-Path ([Environment]::GetFolderPath('Desktop')) 'Celestron Origin Control.lnk')
$StartDir    = (Join-Path $env:APPDATA 'Microsoft\Windows\Start Menu\Programs\Celestron')
$StartLink   = (Join-Path $StartDir 'Celestron Origin Control.lnk')
$TotalSteps  = 8

function Add-Log([string]$M) {
    $ts = Get-Date -Format 'HH:mm:ss'
    try { Add-Content -Path $LogFile -Value "[$ts] $M" -Encoding UTF8 } catch {}
}
function Write-Step([string]$M, [int]$N) {
    $pct = [Math]::Round(($N/$TotalSteps)*100)
    $bar = ('#'*[Math]::Round($pct/5))+(' '*(20-[Math]::Round($pct/5)))
    Write-Host ''
    Write-Host "  [$N/$TotalSteps]  $M" -ForegroundColor White
    Write-Host "  [$bar] $pct%" -ForegroundColor DarkCyan
    Add-Log "STEP $N : $M"
}
function Write-OK([string]$M)   { Write-Host "  OK   $M" -ForegroundColor Green;   Add-Log "OK   : $M" }
function Write-Skip([string]$M) { Write-Host "  --   $M" -ForegroundColor DarkGray; Add-Log "SKIP : $M" }
function Write-Warn([string]$M) { Write-Host "  WARN $M" -ForegroundColor Yellow;  Add-Log "WARN : $M" }
function Exit-OnError([string]$M) {
    Write-Host ''
    Write-Host "  ERROR: $M" -ForegroundColor Red
    Write-Host "  Log: $LogFile" -ForegroundColor DarkGray
    Add-Log "ERROR: $M"
    Write-Host ''
    Write-Host '  Press any key to exit...' -ForegroundColor DarkGray
    $null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
    exit 1
}
function Get-WebFile([string]$Url,[string]$Dest,[string]$Label) {
    Write-Host "  Downloading $Label ..." -ForegroundColor DarkCyan
    Add-Log "GET $Url"
    try {
        $wc = New-Object System.Net.WebClient
        $wc.Headers.Add('User-Agent','CelestronInstaller/2.0.0')
        $wc.DownloadFile($Url,$Dest)
        Write-OK "$Label downloaded"
    } catch { Exit-OnError "Download failed for ${Label}: $_" }
}
function Add-ToUserPath([string]$Dir) {
    $cur = [Environment]::GetEnvironmentVariable('Path','User')
    if ($cur -notlike "*$Dir*") {
        [Environment]::SetEnvironmentVariable('Path',"$cur;$Dir",'User')
        Write-OK "Added to PATH: $Dir"
    } else { Write-Skip "Already in PATH: $Dir" }
    if ($env:Path -notlike "*$Dir*") { $env:Path = "$Dir;$env:Path" }
}
function New-Lnk([string]$P,[string]$T,[string]$A,[string]$W,[string]$D,[string]$I='') {
    $sh = New-Object -ComObject WScript.Shell
    $sc = $sh.CreateShortcut($P)
    $sc.TargetPath=$T; $sc.Arguments=$A; $sc.WorkingDirectory=$W
    $sc.Description=$D; $sc.WindowStyle=1
    if ($I -ne '') { $sc.IconLocation=$I }
    $sc.Save()
    [Runtime.InteropServices.Marshal]::ReleaseComObject($sh) | Out-Null
}
# Run npm using cmd.exe /c so .cmd files work correctly
function Invoke-Npm([string]$WorkDir, [string]$NpmExe, [string[]]$NpmArgs) {
    $argStr = $NpmArgs -join ' '
    $cmdLine = '/c ""' + $NpmExe + '"' + ' ' + $argStr + '"'
    Add-Log "npm cmd: cmd.exe $cmdLine"
    $npmLog = Join-Path $TempDir 'npm_out.log'
    $npmErr = Join-Path $TempDir 'npm_err.log'
    $p = Start-Process 'cmd.exe' `
        -ArgumentList $cmdLine `
        -WorkingDirectory $WorkDir `
        -Wait -PassThru `
        -RedirectStandardOutput $npmLog `
        -RedirectStandardError  $npmErr `
        -WindowStyle Hidden
    return $p.ExitCode
}

# ===========================================================================
Clear-Host
Write-Host ''
Write-Host '  Celestron Origin Control  -  Installer v2.0.0' -ForegroundColor Cyan
Write-Host '  ============================================================' -ForegroundColor DarkCyan
Write-Host '  No administrator rights required.' -ForegroundColor DarkGray
Write-Host ''
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 -bor [Net.SecurityProtocolType]::Tls13

# Step 1 - Dirs
Write-Step 'Creating install directories' 1
foreach ($d in @($TempDir,$InstallDir,$NodeDir,$FFmpegDir,$StartDir)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
}
Write-OK "Install location: $InstallDir"

# Step 2 - Node.js
# We track the node.exe and npm.cmd paths separately.
# If system Node >= 18 exists we use that, but we ALWAYS resolve npm
# as a .cmd file and invoke it via cmd.exe (Start-Process cannot run .cmd directly).
Write-Step 'Installing Node.js v20.11.1 portable (no admin needed)' 2

$NodeExe   = Join-Path $NodeDir 'node.exe'
$PortNpm   = Join-Path $NodeDir 'npm.cmd'
$UseNpmExe = ''     # resolved below - always a full path to npm.cmd
$nodeOk    = $false

# Check if portable node already extracted
if (Test-Path $NodeExe) {
    try {
        $nv = (& $NodeExe --version 2>&1).Trim()
        Write-OK "Node.js $nv already in app directory"
        $UseNpmExe = $PortNpm
        $nodeOk    = $true
    } catch {}
}

# Check system node
if (-not $nodeOk) {
    try {
        $sn = Get-Command node -ErrorAction SilentlyContinue
        if ($sn) {
            $snv = (& node --version 2>&1).Trim()
            $maj = [int](($snv -replace '^v','').Split('.')[0])
            if ($maj -ge 18) {
                Write-OK "System Node.js $snv is sufficient"
                # Resolve system npm - it may be npm.cmd or npm.ps1 etc.
                # We find the npm.cmd next to node.exe for reliability
                $nodeFolder = Split-Path $sn.Source
                $sysNpmCmd  = Join-Path $nodeFolder 'npm.cmd'
                if (Test-Path $sysNpmCmd) {
                    $UseNpmExe = $sysNpmCmd
                } else {
                    # Fall back to wherever npm is on PATH
                    $npmOnPath = Get-Command npm -ErrorAction SilentlyContinue
                    if ($npmOnPath) { $UseNpmExe = $npmOnPath.Source }
                }
                $nodeOk = $true
                # Still add portable NodeDir to PATH for the launcher bat
                # but we won't extract node there - just ensure dir exists
            } else {
                Write-Warn "System Node.js $snv is too old (need v18+), installing portable"
            }
        }
    } catch {}
}

# Download portable node if still needed
if (-not $nodeOk) {
    $nzp = Join-Path $TempDir $NodeZipName
    if (-not (Test-Path $nzp)) { Get-WebFile $NodeZipUrl $nzp 'Node.js v20.11.1 portable zip' }
    else { Write-Skip 'Node.js zip already cached' }
    Write-Host '  Extracting Node.js...' -ForegroundColor DarkCyan
    try {
        Add-Type -AssemblyName System.IO.Compression.FileSystem
        $z   = [IO.Compression.ZipFile]::OpenRead($nzp)
        $top = ($z.Entries[0].FullName -split '/')[0]
        $z.Dispose()
        Expand-Archive -Path $nzp -DestinationPath $TempDir -Force
        $ex = Join-Path $TempDir $top
        Get-ChildItem $ex | ForEach-Object {
            $dst = Join-Path $NodeDir $_.Name
            if (Test-Path $dst) { Remove-Item $dst -Recurse -Force }
            Move-Item $_.FullName $dst -Force
        }
        Remove-Item $ex -Force -ErrorAction SilentlyContinue
        $nv = (& $NodeExe --version 2>&1).Trim()
        Write-OK "Node.js $nv ready"
        $UseNpmExe = $PortNpm
        $nodeOk    = $true
    } catch { Exit-OnError "Node.js extraction failed: $_" }
}

if (-not $UseNpmExe -or -not (Test-Path $UseNpmExe)) {
    Exit-OnError "Cannot locate npm. Tried: $UseNpmExe"
}
Write-OK "npm: $UseNpmExe"
Add-ToUserPath $NodeDir

# Step 3 - FFmpeg
Write-Step 'Installing FFmpeg portable (no admin needed)' 3
$ffOk = $false
try { $fv=(& ffmpeg -version 2>&1)[0]; if($fv -match 'ffmpeg version'){Write-OK 'FFmpeg already in PATH'; $ffOk=$true} } catch {}
if (-not $ffOk) {
    $ffExe = Join-Path $FFmpegBin 'ffmpeg.exe'
    if (-not (Test-Path $ffExe)) {
        $fz = Join-Path $TempDir 'ffmpeg.zip'
        if (-not (Test-Path $fz)) { Get-WebFile $FFmpegUrl $fz 'FFmpeg GPL build' }
        else { Write-Skip 'FFmpeg zip already cached' }
        Write-Host '  Extracting FFmpeg...' -ForegroundColor DarkCyan
        try {
            Add-Type -AssemblyName System.IO.Compression.FileSystem
            $z   = [IO.Compression.ZipFile]::OpenRead($fz)
            $top = ($z.Entries[0].FullName -split '/')[0]
            $z.Dispose()
            Expand-Archive -Path $fz -DestinationPath $TempDir -Force
            $ex = Join-Path $TempDir $top
            if (Test-Path $FFmpegBin) { Remove-Item $FFmpegBin -Recurse -Force }
            Copy-Item (Join-Path $ex 'bin') $FFmpegBin -Recurse -Force
            Remove-Item $ex -Recurse -Force -ErrorAction SilentlyContinue
            Write-OK 'FFmpeg extracted'
        } catch { Exit-OnError "FFmpeg extraction failed: $_" }
    } else { Write-Skip 'FFmpeg already extracted' }
    Add-ToUserPath $FFmpegBin
}

# Step 4 - Copy app files
Write-Step 'Copying application files (cleaning old version first)' 4
$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$appSrc    = Join-Path $scriptDir 'app'
if (-not (Test-Path (Join-Path $appSrc 'package.json'))) {
    Exit-OnError "App source not found at '$appSrc'"
}
# Remove old app source files so stale code never persists across updates.
# We keep node_modules (saves re-downloading Electron) and ffmpeg/node folders.
$keepFolders = @('node_modules', 'node', 'ffmpeg')
if (Test-Path $InstallDir) {
    Get-ChildItem $InstallDir | Where-Object { $_.Name -notin $keepFolders } | ForEach-Object {
        Remove-Item $_.FullName -Recurse -Force -ErrorAction SilentlyContinue
    }
    Write-OK 'Old app files removed'
}
# Copy fresh app files
Get-ChildItem $appSrc | Where-Object { $_.Name -notin @('node_modules','.git','dist') } | ForEach-Object {
    if ($_.PSIsContainer) { Copy-Item $_.FullName (Join-Path $InstallDir $_.Name) -Recurse -Force }
    else { Copy-Item $_.FullName $InstallDir -Force }
}

Write-OK 'App files copied (fresh install)'

# Step 5 - npm install
# IMPORTANT: Start-Process cannot execute .cmd files directly on all Windows versions.
# We always invoke npm via: cmd.exe /c ""<path-to-npm.cmd>" install ..."
Write-Step 'Installing npm packages (Electron ~100 MB download)' 5
$env:Path = "$NodeDir;$env:Path"
Write-Host "  Running npm install via: $UseNpmExe" -ForegroundColor DarkGray
$exitCode = Invoke-Npm $InstallDir $UseNpmExe @('install','--prefer-offline','--no-audit','--no-fund')
if ($exitCode -ne 0) {
    $errTxt = Get-Content (Join-Path $TempDir 'npm_err.log') -Raw -ErrorAction SilentlyContinue
    Exit-OnError "npm install failed (exit $exitCode). Details: $errTxt"
}
Write-OK 'npm packages installed'


# Step 6 - Launcher
Write-Step 'Creating silent launcher' 6
$electronExe = Join-Path $InstallDir 'node_modules\electron\dist\electron.exe'

$b  = '@echo off' + [char]13+[char]10
$b += 'set PATH=' + $NodeDir + ';' + $FFmpegBin + ';%PATH%' + [char]13+[char]10
$b += 'cd /d ' + $InstallDir + [char]13+[char]10
$b += 'if not exist "' + $electronExe + '" goto noelectron' + [char]13+[char]10
$b += '"' + $electronExe + '" . --no-sandbox > nul 2>&1' + [char]13+[char]10
$b += 'exit /b 0' + [char]13+[char]10
$b += ':noelectron' + [char]13+[char]10
$b += 'echo Electron not found, trying npx...' + [char]13+[char]10
$b += '"' + $NodeDir + '\npx.cmd" electron . --no-sandbox' + [char]13+[char]10
$b += 'if errorlevel 1 (' + [char]13+[char]10
$b += '  echo ERROR: App failed to start.' + [char]13+[char]10
$b += '  pause > nul' + [char]13+[char]10
$b += ')' + [char]13+[char]10
[System.IO.File]::WriteAllText($LaunchBat, $b, [System.Text.Encoding]::ASCII)

$v  = 'Set ws = CreateObject("WScript.Shell")' + [char]13+[char]10
$v += 'ws.Run "cmd /c ""' + $LaunchBat + '"" ", 0, False' + [char]13+[char]10
[System.IO.File]::WriteAllText($LaunchVbs, $v, [System.Text.Encoding]::ASCII)
Write-OK 'Silent launcher created'

# Step 7 - Shortcuts
Write-Step 'Creating desktop and Start Menu shortcuts' 7
if (-not (Test-Path $StartDir)) { New-Item -ItemType Directory -Path $StartDir -Force | Out-Null }
$IconPath = Join-Path $InstallDir 'app\src\assets\telescope.ico'

# Create shortcuts via wscript.exe pointing to the silent VBS launcher
# wscript.exe + IconLocation reliably shows the custom icon
New-Lnk $DesktopLink (Join-Path $env:SystemRoot "System32\wscript.exe") ([char]34 + $LaunchVbs + [char]34) $InstallDir "Celestron Origin Control" $IconPath
New-Lnk $StartLink   (Join-Path $env:SystemRoot "System32\wscript.exe") ([char]34 + $LaunchVbs + [char]34) $InstallDir "Celestron Origin Control" $IconPath

Write-OK 'Desktop shortcut created'
Write-OK 'Start Menu entry created'

# Step 8 - Register
Write-Step 'Registering with Windows Apps and Features' 8
$uninstPs = Join-Path $InstallDir 'Uninstall.ps1'
$desktopUrl = [System.IO.Path]::ChangeExtension($DesktopLink, '.url')
$u  = 'Remove-Item -LiteralPath ' + [char]39 + $desktopUrl + [char]39 + ' -Force -ErrorAction SilentlyContinue' + [char]13+[char]10
$u += 'Remove-Item -LiteralPath ' + [char]39 + $StartDir + [char]39 + ' -Recurse -Force -ErrorAction SilentlyContinue' + [char]13+[char]10
$u += 'Remove-Item -Path HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\CelestronOriginControl -Force -ErrorAction SilentlyContinue' + [char]13+[char]10
$u += 'Start-Sleep 1' + [char]13+[char]10
$u += 'Remove-Item -LiteralPath ' + [char]39 + $InstallDir + [char]39 + ' -Recurse -Force -ErrorAction SilentlyContinue' + [char]13+[char]10
$u += 'Write-Host ' + [char]39 + 'Uninstall complete.' + [char]39 + ' -ForegroundColor Green' + [char]13+[char]10
$u += 'Start-Sleep 2' + [char]13+[char]10
[System.IO.File]::WriteAllText($uninstPs, $u, [System.Text.Encoding]::UTF8)
$uninstCmd = 'powershell.exe -ExecutionPolicy Bypass -File "' + $uninstPs + '"'
$reg = 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall\CelestronOriginControl'
if (-not (Test-Path $reg)) { New-Item -Path $reg -Force | Out-Null }
Set-ItemProperty $reg 'DisplayName'     'Celestron Origin Control'
Set-ItemProperty $reg 'DisplayVersion'  '2.0.0'
Set-ItemProperty $reg 'Publisher'       'Celestron Origin Control'
Set-ItemProperty $reg 'InstallLocation' $InstallDir
Set-ItemProperty $reg 'UninstallString' $uninstCmd
Set-ItemProperty $reg 'NoModify' 1 -Type DWord
Set-ItemProperty $reg 'NoRepair' 1 -Type DWord
Write-OK 'Registered in Apps and Features'

# Done
Write-Host ''
Write-Host '  ============================================================' -ForegroundColor Green
Write-Host '  Installation complete!' -ForegroundColor Green
Write-Host '  ============================================================' -ForegroundColor Green
Write-Host ''
Write-Host '  Double-click the desktop shortcut to launch.' -ForegroundColor White
Write-Host '  No CMD window will appear - the app opens silently.' -ForegroundColor DarkGray
Write-Host "  Log: $LogFile" -ForegroundColor DarkGray
Write-Host ''
$ch = Read-Host '  Launch now? [Y/n]'
if ($ch -ne 'n' -and $ch -ne 'N') {
    Write-Host '  Launching...' -ForegroundColor Cyan
    Start-Process wscript.exe -ArgumentList ('"' + $LaunchVbs + '"')
    Start-Sleep 4
    Write-Host '  The app window should now be open.' -ForegroundColor Green
}
Write-Host ''
Write-Host '  Press any key to close this installer...' -ForegroundColor DarkGray
$null = $Host.UI.RawUI.ReadKey('NoEcho,IncludeKeyDown')
