@echo off
title Building Celestron Origin Control Installer...
echo.
echo   =====================================================
echo    Build Proper Windows EXE Installer
echo   =====================================================
echo.
echo   electron-builder will create a proper NSIS .exe
echo   installer in the dist\ folder.
echo.
pause

set INSTALL=%LOCALAPPDATA%\CelestronOriginControl
set NODE=%INSTALL%\node\node.exe
set NPM=%INSTALL%\node\npm.cmd

if not exist "%INSTALL%" (
    echo ERROR: App not installed. Run Install.bat first.
    pause
    exit /b 1
)

echo Building... this takes a few minutes.
echo.
cd /d "%INSTALL%"
set PATH=%INSTALL%\node;%PATH%
"%NPM%" run build

if errorlevel 1 (
    echo.
    echo Build failed. See output above.
    pause
    exit /b 1
)

echo.
echo =====================================================
echo  Done! Find your installer in:
echo  %INSTALL%\dist\
echo =====================================================
echo.
explorer "%INSTALL%\dist\"
pause
