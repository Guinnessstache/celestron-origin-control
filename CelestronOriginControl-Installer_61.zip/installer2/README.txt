Celestron Origin Control - Installer
=====================================

HOW TO INSTALL
--------------
1. Extract this zip to any folder
2. Double-click Install.bat
3. Follow the prompts

No admin rights needed.

AFTER INSTALL
-------------
Double-click the desktop shortcut.
The app opens silently - no black CMD window appears.

UNINSTALL
---------
Run Uninstall.bat, or:
Windows Settings > Apps > search Celestron > Uninstall

REQUIREMENTS
------------
Windows 10 or 11 (64-bit)
Internet connection (~200 MB download)
No admin rights needed

TROUBLESHOOTING
---------------
Log: %TEMP%\CelestronInstall\install.log
