@echo off
set /p c=   Type YES to uninstall Celestron Origin Control: 
if /i not "%c%"=="YES" exit /b 0
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%LOCALAPPDATA%\CelestronOriginControl\Uninstall.ps1"
pause
