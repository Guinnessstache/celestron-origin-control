@echo off
setlocal
title Celestron Origin Control - Installer
echo.
echo   =====================================================
echo    Celestron Origin Control - Installer
echo   =====================================================
echo.
echo   This will install:
echo     - Node.js LTS  (if not already installed)
echo     - FFmpeg        (if not already installed)
echo     - Celestron Origin Control app
echo.
echo   Install folder: %LOCALAPPDATA%\CelestronOriginControl
echo.
pause
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install.ps1"
if errorlevel 1 (
    echo.
    echo   Installation failed. Log: %TEMP%\CelestronInstall\install.log
    pause
)
endlocal
